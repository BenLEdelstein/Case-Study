/**This Business Object class is used to handle Property Information
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import com.cts.insurance.homequote.dao.PropertyDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Property;

public class PropertyBO {

	/**This method gets the Property object identified by the quoteId through the PropertyDAO class
	 * @param quoteId: This is the identifier of the Property object
	 * @return A Property object matched by the quoteId
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PropertyDAO class
	 */
	public Property getProperty(final int quoteId) throws HomequoteBusinessException{

		final PropertyDAO propertyDAO = new PropertyDAO();
		try {
			return propertyDAO.getProperty(quoteId);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	/**This method saves a Property record through the PropertyDAO class
	 * @param property: This is a Property object to be saved into the database
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PropertyDAO class
	 */
	public void saveProperty(final Property property) throws HomequoteBusinessException{

		final PropertyDAO propertyDAO = new PropertyDAO();
		try
		{	
			propertyDAO.saveProperty(property);
		}
		catch(HomequoteSystemException e)
		{
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
}
