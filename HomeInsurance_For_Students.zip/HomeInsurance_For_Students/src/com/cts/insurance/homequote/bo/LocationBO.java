/**This Business Object class is used to handle Location Information
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import java.util.List;

import com.cts.insurance.homequote.dao.LocationDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Location;

public class LocationBO {

	/**This method saves a Location object to database through the LocationDAO class
	 * @param location is a Location object containing QUOTE_ID, RESIDENCE_TYPE, 
	 * ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE, USER_NAME
	 * @return An integer representing QuoteID
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from LocationDAO
	 */
	public int saveHomeLocation(final Location location) throws HomequoteBusinessException{

		final LocationDAO locationDAO = new LocationDAO();
		try {
			return locationDAO.saveLocation(location);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method fetches the Location object identified by quoteID through the LocationDAO class
	 * @param quoteId is an integer representing the QuoteID
	 * @return A Location object identified by quoteID
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from LocationDAO class
	 */
	public Location getHomeLocation(int quoteId) throws HomequoteBusinessException{

		final LocationDAO locationDAO = new LocationDAO();
		try {
			return locationDAO.getLocation(quoteId);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method fetches a list of QuoteIDs belonging to the user identified by userName
	 * @param userName is a String representing the userName of the user whose QuoteIds are being fetched
	 * @return A List of Location objects belonging to the user
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException for LocationDao Class
	 */
	public List<Location> getQuoteIds(String userName) throws HomequoteBusinessException{

		final LocationDAO locationDAO = new LocationDAO();
		try {
			return locationDAO.getQuoteIds(userName);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
}
