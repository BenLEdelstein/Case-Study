/**This Business Object class is used to handle Login Information
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import java.util.List;

import com.cts.insurance.homequote.dao.LoginDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.User;

public class LoginBO {

	/**This method returns User object identified by userName through LoginDAO class 
	 * @param userName is a String value used to fetch the user object from database
	 * @return A User object
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from LoginDAO class
	 */
	public User getUser(final String userName) throws HomequoteBusinessException{

		final LoginDAO loginDAO = new LoginDAO();
		try {
			return loginDAO.getUser(userName);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method returns All User objects through LoginDAO class 
	 * @return A List of User objects
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from LoginDAO class
	 */
	public static List<User> getAllUsers() throws HomequoteBusinessException{

		try {
			return LoginDAO.getAllUsers();
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method saves a User object into the database through the LoginDAO class
	 * @param user is the User object to be saved into the database
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from LoginDAO class
	 */
	public void registerUser(final User user) throws HomequoteBusinessException{

		final LoginDAO loginDAO = new LoginDAO();
		try {
			loginDAO.saveUser(user);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
}
