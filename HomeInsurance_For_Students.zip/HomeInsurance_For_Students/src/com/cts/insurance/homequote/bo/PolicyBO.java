/**This Business Object class is used to handle Policy Information
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.cts.insurance.homequote.dao.PolicyDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Policy;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class PolicyBO {
	/**This method saves policy record into the database using the PolicyDAO class
	 * @param quoteId: This is the QuoteID to save the record under
	 * @param policyEffDate: This is a String in the form "yyyy-MM-dd" representing the start date of the policy
	 * @param term: This is an integer representing the policy term
	 * @return Returns a policy object
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException
	 */
	public Policy savePolicy(final int quoteId, final String policyEffDate, final int term) throws HomequoteBusinessException{
		final PolicyDAO policyDAO = new PolicyDAO();
		try
		{	
			final Policy policy = new Policy();		
			policy.setQuoteId(quoteId);
			policy.setPolicyEffDate(policyEffDate);
			policy.setPolicyEndDate(getDateAfterOneYear(policyEffDate));
			policy.setPolicyTerm(term);
			policy.setPolicyKey(quoteId + "_" + policy.getPolicyTerm());
			policy.setPolicyStatus(HomeInsuranceConstants.STATUS_ACTIVE);
			policyDAO.savePolicy(policy);
			return policy;
		}
		catch(HomequoteSystemException e)
		{
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}

	/**This method gets a list of Policy objects
	 * @param userName: This is the user who the policies belong to
	 * @return a list of Policy objects belonging to the user
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PolicyDAO class
	 */
	public List<Policy> getPolicies(final String userName) throws HomequoteBusinessException {

		final PolicyDAO policyDAO = new PolicyDAO();
		try {
			return policyDAO.getPolicies(userName);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method gets a Policy object
	 * @param quoteId: This is the QuoteID of the policy
	 * @return a Policy object identified by quoteID
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PolicyDAO class
	 */
	public Policy getPolicy(final int quoteId) throws HomequoteBusinessException {

		final PolicyDAO policyDAO = new PolicyDAO();
		try {
			return policyDAO.getPolicy(quoteId);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method cancels the policy through the PolicyDAO class
	 * @param policyKey: This is the Policy identifying key
	 * @return A Policy object containing the found policy
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PolicyDAO class
	 */
	public Policy cancelPolicy(final String policyKey) throws HomequoteBusinessException {

		final PolicyDAO policyDAO = new PolicyDAO();
		try {
			return policyDAO.cancelPolicy(policyKey);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	
	/**This method renews the policy through the PolicyDAO class
	 * @param policyKey: This is the policy identifying key
	 * @return A Policy object containing the found policy
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from PolicyDAO class
	 */
	public Policy renewPolicy(final String policyKey) throws HomequoteBusinessException {

		final PolicyDAO policyDAO = new PolicyDAO();
		try {
			return policyDAO.renewPolicy(policyKey);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	/**This method returns a String representation of the date one year after the policy effective start date
	 * @param policyEffectiveDate: This is the policy effective start date
	 * @return A String representation of the date one year after the policy effective start date
	 * @throws HomequoteBusinessException upon catching ParseException from SimpleDateFormat class
	 */
	public static String getDateAfterOneYear(final String policyEffDate) throws HomequoteBusinessException 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			sdf.parse(policyEffDate);
		} catch (ParseException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
		Calendar cal = sdf.getCalendar();
		cal.add(Calendar.YEAR, 1);
		return sdf.format(cal.getTime());
	}
}
