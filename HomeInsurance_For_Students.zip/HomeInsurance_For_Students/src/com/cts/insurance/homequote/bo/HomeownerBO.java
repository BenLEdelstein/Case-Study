/**This Business Object class is used to handle Homeowner Information
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.bo;

import com.cts.insurance.homequote.dao.HomeownerDAO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Homeowner;

public class HomeownerBO {

	/**This method returns Homeowner object obtained through HomeownerDAO Class
	 * It contains the home owner information
	 * @param quoteId is the identifier used to fetch the home owner record
	 * @return A Homeowner object containing QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from HomeownerDAO class
	 */
	public Homeowner getHomeownerInfo(final int quoteId) throws HomequoteBusinessException{

		final HomeownerDAO homeownerDAO = new HomeownerDAO();
		try {
			return homeownerDAO.getHomeowner(quoteId);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
	/**This method saves Homeowner object information to the database through the HomeownerDAO class
	 * @param homeowner is a Homeowner object containing QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS
	 * @throws HomequoteBusinessException upon catching HomequoteSystemException from HomeownerDAO class
	 */
	public void saveHomeownerInfo(final Homeowner homeowner) throws HomequoteBusinessException{

		final HomeownerDAO homeownerDAO = new HomeownerDAO();
        try {
			homeownerDAO.saveHomeowner(homeowner);
		} catch (HomequoteSystemException e) {
			// HomequoteSystemException is unhandled throw HomequoteBusinessException instead
			throw new HomequoteBusinessException(e.getLocalizedMessage());
		}
	}
}
