/**
 * POJO JavaBean for User
 * 
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.model;

import java.io.Serializable;

public class User implements Serializable{
	/**
	 * Serialized
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The user name
	 */
	 private String userName = "";

	/**
	 * The login password
	 */
	 private String password = "";
	 
	 private String userRole = "";

	/**
	 * Gets the userName
	 *
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the userName
	 *
	 * @param userName
	 */
	public void setUserName(final String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the password
	 *
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password
	 *
	 * @param password
	 */
	public void setPassword(final String password) {
		this.password = password;
	}

	/**
	 * @return the userRole
	 */
	public String getUserRole() {
		return userRole;
	}

	/**
	 * @param userRole the userRole to set
	 */
	public void setUserRole(final String userRole) {
		this.userRole = userRole;
	}
	
	/**
	 * This method returns a formatted String of the User object
	 */
	@Override
	public String toString() {
		return "[User Name: "+userName+"] [Password: "+password+"] [User Role: "+userRole+"]";
	}
	
	/**
	 * This method prints original Object class string - which is the memory location
	 * @return a String of the object location in memory
	 */
	public String getMemLoc() {
		return super.toString();
	}
	
}