/**This Data Access Object class manages database transactions of the Policy data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.PolicyBO;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Policy;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class PolicyDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG =  Logger.getLogger(PolicyDAO.class);
	
	/**This method fetches a List of Policy objects from the database by performing database transaction
	 * @param userName is a String value identifying the Policies to be fetched
	 * @return A List of Policy Objects
	 * @throws HomequoteSystemException
	 */
	public List<Policy> getPolicies(final String userName) throws HomequoteSystemException {
		LOG.info("PolicyDAO.getPolicies -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		ArrayList<Policy> policyList = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PolicyDAO.getPolicies - Connection Successfull");
			//SELECT * from Policy p, Location l where p.QUOTE_ID= l.QUOTE_ID and l.USER_NAME = ?
			stmt = conn.prepareStatement(SqlQueries.GET_POLICIES);
			stmt.setString(1, userName);
			LOG.info("PolicyDAO.getPolicies - SQL Statement: "+SqlQueries.GET_POLICIES+" Value: "+userName);
			resultSet = stmt.executeQuery();
			LOG.info("PolicyDAO.getPolicies - Queried Database");
			policyList = new ArrayList<Policy>();
			while (resultSet.next()) {
				Policy policy = new Policy();
				policy.setPolicyKey(resultSet.getString(1));
				policy.setQuoteId(resultSet.getInt(2));
				policy.setPolicyEffDate(resultSet.getString(3));
				policy.setPolicyEndDate(resultSet.getString(4));
				policy.setPolicyTerm(resultSet.getInt(5));
				policy.setPolicyStatus(resultSet.getString(6));
				policyList.add(policy);
				LOG.info("PolicyDAO.getPolicies - Policy Added to List: "+ policy.toString());
			}
			LOG.info("PolicyDAO.getPolicies - End of List");
		}
		catch(Exception e)
		{
			LOG.error("PolicyDAO.getPolicies - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PolicyDAO.getPolicies -- End");
		return policyList;
	}
	
	/**This method fetches a Policy object from the database by performing database transaction
	 * @param quoteId is a String value identifying the Policies to be fetched
	 * @return A Policy Object
	 * @throws HomequoteSystemException
	 */
	public Policy getPolicy(final int quoteId) throws HomequoteSystemException {
		LOG.info("PolicyDAO.getPolicies -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Policy policy = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PolicyDAO.getPolicies - Connection Successfull");
			//SELECT * from Policy p, Location l where p.QUOTE_ID= l.QUOTE_ID and l.USER_NAME = ?
			stmt = conn.prepareStatement(SqlQueries.GET_POLICY_BY_QUOTE_ID);
			stmt.setInt(1, quoteId);
			LOG.info("PolicyDAO.getPolicies - SQL Statement: "+SqlQueries.GET_POLICIES+" Value: "+quoteId);
			resultSet = stmt.executeQuery();
			LOG.info("PolicyDAO.getPolicies - Queried Database");
			if (resultSet.next()) {
				policy = new Policy();
				policy.setPolicyKey(resultSet.getString(1));
				policy.setQuoteId(resultSet.getInt(2));
				policy.setPolicyEffDate(resultSet.getString(3));
				policy.setPolicyEndDate(resultSet.getString(4));
				policy.setPolicyTerm(resultSet.getInt(5));
				policy.setPolicyStatus(resultSet.getString(6));
			}
			LOG.info("PolicyDAO.getPolicies - Got policy"+policy.toString());
		}
		catch(Exception e)
		{
			LOG.error("PolicyDAO.getPolicies - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PolicyDAO.getPolicies -- End");
		return policy;
	}
	
	/**This method saves the Policy object information by performing database transaction
	 * @param policy is a Policy object containing POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE, POLICY_END_DATE, POLICY_TERM, POLICY_STATUS
	 * @throws HomequoteSystemException
	 */
	public void savePolicy(final Policy policy) throws HomequoteSystemException {
		LOG.info("PolicyDAO.savePolicy -- Start");
		LOG.info("PolicyDAO.savePolicy -- Validating Policy Data");
		validate(policy);
		LOG.info("PolicyDAO.savePolicy -- Validation Complete");
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PolicyDAO.savePolicy - Connection Successfull");
			//INSERT INTO Policy (POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE,
			//POLICY_END_DATE, POLICY_TERM, POLICY_STATUS) VALUES
			//('14_1', 14, '2013-07-17', '2014-07-17', 1, 'ACTIVE');
			stmt = conn.prepareStatement(SqlQueries.SAVE_POLICY);
			stmt.setString(1, policy.getPolicyKey());
			stmt.setInt(2, policy.getQuoteId());
			stmt.setString(3, policy.getPolicyEffDate());
			stmt.setString(4, policy.getPolicyEndDate());
			stmt.setInt(5, policy.getPolicyTerm());
			stmt.setString(6, policy.getPolicyStatus());
			LOG.info("PolicyDAO.savePolicy - SQL Statement: "+SqlQueries.SAVE_POLICY+" Values: "+policy.toString());
			stmt.executeUpdate();
			LOG.info("PolicyDAO.savePolicy - Updated Database");
		}
		catch(Exception e)
		{
			LOG.error("PolicyDAO.savePolicy - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PolicyDAO.savePolicy -- End");
	}

	/**This method validates the policy data before saving to the database
	 * @param policy is a Policy object containing POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE, POLICY_END_DATE, POLICY_TERM, POLICY_STATUS
	 * @throws HomequoteSystemException
	 */
	private void validate(Policy policy)throws HomequoteSystemException {
		if(!policy.getPolicyEffDate().matches("^[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
			throw new HomequoteSystemException("Bad value for Policy Effective Date");
		}
		if(!policy.getPolicyEndDate().matches("^[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
			throw new HomequoteSystemException("Bad value for Policy End Date");
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d1,d2, now, sixty;
		try {
			d1 = sdf.parse(policy.getPolicyEffDate());
			d2 = sdf.parse(policy.getPolicyEndDate());
			String date = sdf.format(new Date());
			now = sdf.parse(date);
			Calendar c = sdf.getCalendar();
			c.add(Calendar.DATE, 60);
			sixty = c.getTime();
		}catch(ParseException p) {
			throw new HomequoteSystemException(p.getLocalizedMessage());
		}
		if(d1.compareTo(now)<0 || d1.compareTo(sixty)>0) {
			throw new HomequoteSystemException("Policy Effective date must be from now to 60 days in the future");
		}
		if(d1.compareTo(d2)>0) {
			throw new HomequoteSystemException("Policy Effective Date cannot be after Policy End Date");
		}
		LOG.info("PolicyDAO.savePolicy -- Dates Valdated");
		if(policy.getPolicyTerm()<=0) {
			throw new HomequoteSystemException("Term is not a valid value");
		}
		LOG.info("PolicyDAO.savePolicy -- Term Valdated");
		if(!policy.getPolicyStatus().equals("ACTIVE")&&!policy.getPolicyStatus().equals("RENEWED")&&
				!policy.getPolicyStatus().equals("CANCELLED")) {
			throw new HomequoteSystemException("Bad value for policy status");
		}
		LOG.info("PolicyDAO.savePolicy -- Status Valdated");
	}

	/**This method renews a Policy by marking it cancelled by database transaction
	 * @param policyKey is a String value that identifies the policy to be modified
	 * @return A Policy object containing POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE, POLICY_END_DATE, POLICY_TERM, POLICY_STATUS 
	 */
	public Policy renewPolicy(final String policyKey) throws HomequoteSystemException
	{
		LOG.info("Renewing Policy");
		return modifyPolicy(HomeInsuranceConstants.RENEW, policyKey);
	}
	/**This method cancels a Policy by marking it cancelled by database transaction
	 * @param policyKey is a String value that identifies the policy to be modified
	 * @return A Policy object containing POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE, POLICY_END_DATE, POLICY_TERM, POLICY_STATUS
	 */
	public Policy cancelPolicy(final String policyKey) throws HomequoteSystemException
	{	
		LOG.info("Cancelling Policy");
		return modifyPolicy(HomeInsuranceConstants.CANCEL, policyKey);
	}
	
	/**This method updates a Policy by database transaction
	 * @param updateAction is a String value representing the modification to be performed (Cancel or Renew)
	 * @param policyKey is a String value that identifies the policy to be modified
	 * @return A Policy object containing POLICY_KEY, QUOTE_ID, POLICY_EFFECTIVE_DATE, POLICY_END_DATE, POLICY_TERM, POLICY_STATUS
	 * @throws HomequoteSystemException
	 */
	public Policy modifyPolicy(final String updateAction, final String policyKey) throws HomequoteSystemException {
		LOG.info("PolicyDAO.modifyPolicy -- Start");
		Connection conn = null;
		ResultSet resultSet = null;
		Policy policy = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PolicyDAO.modifyPolicy - Connection Successfull");
			if(updateAction.equals(HomeInsuranceConstants.RENEW))
			{
				PreparedStatement stmt = conn.prepareStatement(SqlQueries.GET_POLICY);
				stmt.setString(1, policyKey);
				LOG.info("PolicyDAO.modifyPolicy - SQL Statement: "+SqlQueries.GET_POLICY+" Value: "+policyKey);
				resultSet = stmt.executeQuery();
				LOG.info("PolicyDAO.modifyPolicy - Queried Database");
				String endDate = null;
				if (resultSet.next())
					endDate = resultSet.getString("POLICY_END_DATE");
				LOG.info("PolicyDAO.modifyPolicy - End Date fetched: "+endDate);
				resultSet.close();
				stmt.close();
				
				stmt = conn.prepareStatement(SqlQueries.RENEW_POLICY);
				stmt.setString(1, PolicyBO.getDateAfterOneYear(endDate));
				stmt.setString(2, policyKey);
				LOG.info("PolicyDAO.modifyPolicy - SQL Statement: "+SqlQueries.RENEW_POLICY+" Values: ["+PolicyBO.getDateAfterOneYear(endDate)+", "+policyKey+"]");
				stmt.executeUpdate();
				LOG.info("PolicyDAO.modifyPolicy - Updated Database");
				stmt.close();
			} else if(updateAction.equals(HomeInsuranceConstants.CANCEL))
			{
				final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			    final String todaysDate = sdf.format(Calendar.getInstance().getTime());
				final PreparedStatement stmt = conn.prepareStatement(SqlQueries.CANCEL_POLICY);
				stmt.setString(1, todaysDate);
				stmt.setString(2, policyKey);
				LOG.info("PolicyDAO.modifyPolicy - SQL Statement: "+SqlQueries.CANCEL_POLICY+" Value: "+policyKey);
				stmt.executeUpdate();
				LOG.info("PolicyDAO.modifyPolicy - Updated Database");
				stmt.close();
			}
			
			//SELECT * from Policy where POLICY_KEY = ?
			final PreparedStatement stmt = conn.prepareStatement(SqlQueries.GET_POLICY);
			stmt.setString(1, policyKey);
			LOG.info("PolicyDAO.modifyPolicy - SQL Statement: "+SqlQueries.GET_POLICY+" Value: "+policyKey);
			resultSet = stmt.executeQuery();
			LOG.info("PolicyDAO.modifyPolicy - Queried Database");
			policy = new Policy();
			if (resultSet.next()) {
				policy.setPolicyKey(resultSet.getString(1));
				policy.setQuoteId(resultSet.getInt(2));
				policy.setPolicyEffDate(resultSet.getString(3));
				policy.setPolicyEndDate(resultSet.getString(4));
				policy.setPolicyTerm(resultSet.getInt(5));
				policy.setPolicyStatus(resultSet.getString(6));
				LOG.info("PolicyDAO.modifyPolicy - Policy fetched from Database: "+policy.toString());
			}
			else
				LOG.info("PolicyDAO.modifyPolicy - Empty");
		}
		catch(Exception e)
		{
			LOG.error("PolicyDAO.modifyPolicy - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PolicyDAO.modifyPolicy -- End");
		return policy;
	}
}
