/**This Data Access Object class manages database transactions of the Quote data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Quote;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class QuoteDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG =  Logger.getLogger(QuoteDAO.class);
	
	/**This method fetches a Quote object from the database by performing database transaction
	 * @param quoteId is a String value used to fetch the Quote object
	 * @return A Quote object containing QUOTE_ID, PREMIUM, DWELLING_COVERAGE, DETACHED_STRUCTURE, PERSONAL_PROPERTY, ADDNL_LIVING_EXPENSE, MEDICAL_EXPENSE, DEDUCTIBLE
	 * @throws HomequoteSystemException
	 */
	public Quote getQuote(final int quoteId) throws HomequoteSystemException {
		LOG.info("PropertyDAO.saveQuote -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Quote quote = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("QuoteDAO.getQuote - Connection Successfull");
			//select * from Quote where QUOTE_ID = ?
			stmt = conn.prepareStatement(SqlQueries.GET_QUOTE);
			stmt.setInt(1, quoteId);
			LOG.info("QuoteDAO.getQuote - SQL Statement: "+SqlQueries.GET_QUOTE+" Value: "+quoteId);
			resultSet = stmt.executeQuery();
			LOG.info("QuoteDAO.getQuote - Queried Database");
			quote = new Quote();
			if (resultSet.next()) {
				quote.setQuoteId(resultSet.getInt(1));
				quote.setPremium(resultSet.getDouble(2));
				quote.setDwellingCoverage(resultSet.getDouble(3));
				quote.setDetachedStructure(resultSet.getDouble(4));
				quote.setPersonalProperty(resultSet.getDouble(5));
				quote.setAddnlLivgExpense(resultSet.getDouble(6));
				quote.setMedicalExpense(resultSet.getDouble(7));
				quote.setDeductible(resultSet.getDouble(8));
				LOG.info("QuoteDAO.getQuote - Quote fetched from Database: "+quote.toString());
			}
			else
				LOG.info("QuoteDAO.getQuote - Empty");
		}
		catch(Exception e)
		{
			LOG.error("QuoteDAO.getQuote - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PropertyDAO.saveQuote -- End");
		return quote;
	}
	
	/**This method saves the Quote object information by performing database transaction
	 * @param quote is a Quote object containing QUOTE_ID, PREMIUM, DWELLING_COVERAGE, DETACHED_STRUCTURE, PERSONAL_PROPERTY, ADDNL_LIVING_EXPENSE, MEDICAL_EXPENSE, DEDUCTIBLE
	 * @throws HomequoteSystemException
	 */
	public void saveQuote(final Quote quote) throws HomequoteSystemException {
		LOG.info("PropertyDAO.saveQuote - starts");
		LOG.info("PropertyDAO.saveQuote - Validating Data");
		validate(quote);
		LOG.info("PropertyDAO.saveQuote - Validation Complete");
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("QuoteDAO.saveQuote - Connection Successfull");
			//INSERT INTO Quote (QUOTE_ID, PREMIUM, DWELLING_COVERAGE, DETACHED_STRUCTURE,
			//PERSONAL_PROPERTY, ADDNL_LIVING_EXPENSE, MEDICAL_EXPENSE, DEDUCTIBLE) VALUES
			//(?, ?, ?, ?, ?, ?, ?, ?);
			stmt = conn.prepareStatement(SqlQueries.SAVE_QUOTE);
			stmt.setInt(1, quote.getQuoteId());
			stmt.setDouble(2, quote.getPremium());
			stmt.setDouble(3, quote.getDwellingCoverage());
			stmt.setDouble(4, quote.getDetachedStructure());
			stmt.setDouble(5, quote.getPersonalProperty());
			stmt.setDouble(6, quote.getAddnlLivgExpense());
			stmt.setDouble(7, quote.getMedicalExpense());
			stmt.setDouble(8, quote.getDeductible());
			LOG.info("QuoteDAO.saveQuote - SQL Statement: "+SqlQueries.SAVE_QUOTE+" Values: "+quote.toString());
			stmt.executeUpdate();
			LOG.info("QuoteDAO.saveQuote - Updated Database");
		}
		catch(Exception e)
		{
			LOG.error("QuoteDAO.saveQuote - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PropertyDAO.saveQuote -- End");
	}
	/**This method validates the quote data before saving to the database
	 * @param quote is a Quote object containing QUOTE_ID, PREMIUM, DWELLING_COVERAGE, DETACHED_STRUCTURE, PERSONAL_PROPERTY, ADDNL_LIVING_EXPENSE, MEDICAL_EXPENSE, DEDUCTIBLE
	 * @throws HomequoteSystemException
	 */
	private void validate(Quote quote) throws HomequoteSystemException {
		if(quote.getPremium()<0) {
			throw new HomequoteSystemException("Bad value for Premium");
		}
		LOG.info("PropertyDAO.saveQuote -- Premium Validated");
		if(quote.getDwellingCoverage()<0) {
			throw new HomequoteSystemException("Bad value for Dwelling Coverage");
		}
		LOG.info("PropertyDAO.saveQuote -- Dwelling Coverage Validated");
		if(quote.getDetachedStructure()<0) {
			throw new HomequoteSystemException("Bad value for Detached Structure");
		}
		LOG.info("PropertyDAO.saveQuote -- Detached Structure Validated");
		if(quote.getPersonalProperty()<0) {
			throw new HomequoteSystemException("Bad value for Personal Property Coverage");
		}
		LOG.info("PropertyDAO.saveQuote -- Personal Property Coverage Validated");
		if(quote.getAddnlLivgExpense()<0) {
			throw new HomequoteSystemException("Bad value for Additional Living Expense");
		}
		LOG.info("PropertyDAO.saveQuote -- Additional Living Expense Validated");
		if(quote.getMedicalExpense()<0) {
			throw new HomequoteSystemException("Bad value for Medical Expense");
		}
		LOG.info("PropertyDAO.saveQuote -- Medical Expense Validated");
		if(quote.getDeductible()<0) {
			throw new HomequoteSystemException("Bad value for Deductible");
		}
		LOG.info("PropertyDAO.saveQuote -- Deductible Validated");
	}
}
