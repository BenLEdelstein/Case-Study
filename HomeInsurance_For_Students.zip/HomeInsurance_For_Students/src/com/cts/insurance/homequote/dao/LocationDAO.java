/**This Data Access Object class manages database transactions of the Location data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Location;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class LocationDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG = Logger.getLogger(LocationDAO.class);
	
	/**This method saves the Location object information by performing database transaction
	 * @param location is a Location object containing QUOTE_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE, USER_NAME
	 * @return An integer representing the QuoteID
	 * @throws HomequoteSystemException
	 */
	public int saveLocation(final Location location) throws HomequoteSystemException
	{
		LOG.info("LocationDAO.saveLocation -- Start");
		LOG.info("LocationDAO.saveLocation -- Validating Data");
		validate(location);
		LOG.info("LocationDAO.saveLocation -- Validation Complete");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int quoteId = 0;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("LocationDAO.saveLocation - Connection Successfull");
			//"INSERT INTO Location (QUOTE_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE,USER_NAME) VALUES
			//(NULL, ?, ?, ?, ?, ?, ?, ?, ?)";
			stmt = conn.prepareStatement(SqlQueries.SAVE_LOCATION);
			stmt.setString(1, location.getResidenceType());
			stmt.setString(2, location.getAddressLine1());
			stmt.setString(3, location.getAddressLine2());
			stmt.setString(4, location.getCity());
			stmt.setString(5, location.getState());
			stmt.setString(6, location.getZip());
			stmt.setString(7, location.getResidenceUse());
			stmt.setString(8, location.getUserName());
			LOG.info("LocationDAO.saveLocation - SQL Statement: "+SqlQueries.SAVE_LOCATION+location.toString());
			
			stmt.executeUpdate();
			LOG.info("LocationDAO.saveLocation - Updated Database");
			stmt.close();
			
			LOG.info("LocationDAO.saveLocation - Fetching QuoteID from database");
			//"SELECT QUOTE_ID from Location where RESIDENCE_TYPE = ? and " +
			//"ADDRESS_LINE_1 = ? and ADDRESS_LINE_2 = ? and CITY = ? and STATE = ? and ZIP = ? and RESIDENCE_USE = ? and USER_NAME = ?)";
			stmt = conn.prepareStatement(SqlQueries.GET_QUOTE_ID);
			stmt.setString(1, location.getResidenceType());
			stmt.setString(2, location.getAddressLine1());
			stmt.setString(3, location.getAddressLine2());
			stmt.setString(4, location.getCity());
			stmt.setString(5, location.getState());
			stmt.setString(6, location.getZip());
			stmt.setString(7, location.getResidenceUse());
			stmt.setString(8, location.getUserName());
			LOG.info("LocationDAO.saveLocation - SQL Statement: "+SqlQueries.GET_QUOTE_ID+" Values: "+location.toString());
			stmt.executeQuery();
			LOG.info("LocationDAO.saveLocation - Queried Database");
			resultSet = stmt.executeQuery();
			if (resultSet.next()) {
				quoteId = resultSet.getInt(1);
				LOG.info("LocationDAO.saveLocation - Got QuoteID: "+quoteId);
			}
			else
				LOG.info("LocationDAO.saveLocation - Empty");
		}
		catch(Exception e)
		{
			LOG.error("LocationDAO.saveLocation - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("LocationDAO.saveLocation -- End");
		return quoteId;
	}
	
	/**This method validates the data in the Location object before saving to database
	 * @param location is a Location object containing QUOTE_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE, USER_NAME
	 * @throws HomequoteSystemException
	 */
	private void validate(Location location) throws HomequoteSystemException {
		if(!location.getResidenceType().equals("Single-Family Home") &&
				!location.getResidenceType().equals("Condo") &&
				!location.getResidenceType().equals("Townhouse") &&
				!location.getResidenceType().equals("Rowhouse") &&
				!location.getResidenceType().equals("Duplex") &&
				!location.getResidenceType().equals("Apartment")) {
			throw new HomequoteSystemException("Invalid value for residence type");
		}
		LOG.info("LocationDAO.saveLocation -- Residence Type Validated");
		if(location.getAddressLine1().matches("[^A-Za-z0-9,-/. ]")) {
			throw new HomequoteSystemException("Bad address 1 value");
		}
		if(location.getAddressLine1().length()>49) {
			throw new HomequoteSystemException("Address 1 too long");
		}
		LOG.info("LocationDAO.saveLocation -- Address1 Validated");
		if(location.getAddressLine2()!=null && location.getAddressLine2().matches("[^A-Za-z0-9,-/. ]")) {
			throw new HomequoteSystemException("Bad address 2 value");
		}
		if(location.getAddressLine2().length()>99) {
			throw new HomequoteSystemException("Address 2 too long");
		}
		LOG.info("LocationDAO.saveLocation -- Address2 Validated");
		if(location.getCity().matches("[^A-Za-z0-9 ]")) {
			throw new HomequoteSystemException("Bad city value");
		}
		if(location.getCity().length()>14) {
			throw new HomequoteSystemException("City value too long");
		}
		LOG.info("LocationDAO.saveLocation -- City Validated");
		if(location.getState().matches("[^A-Za-z0-9 ]")) {
			throw new HomequoteSystemException("Bad state value");
		}
		if(location.getState().length()>14) {
			throw new HomequoteSystemException("State value too long");
		}
		LOG.info("LocationDAO.saveLocation -- State Validated");
		if(location.getZip().length()!=5 && location.getZip().length()!=9) {
			throw new HomequoteSystemException("Zip wrong length");
		}
		if(location.getZip().matches("[^0-9]")) {
			throw new HomequoteSystemException("Zip must be numbers only");
		}
		LOG.info("LocationDAO.saveLocation -- Zip Validated");
		if(!location.getResidenceUse().equals("Primary")&&
				!location.getResidenceUse().equals("Secondary")&&
				!location.getResidenceUse().equals("Rental Property")) {
			throw new HomequoteSystemException("Bad value for residence use");
		}
		LOG.info("LocationDAO.saveLocation -- Residence Use Validated");
	}

	/**This method fetches a List of Policy objects from the database by performing database transaction
	 * @param quoteId is an integer representing the QuoteID used to fetch the Location object
	 * @return A Location object containing QUOTE_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE, USER_NAME
	 * @throws HomequoteSystemException
	 */
	public Location getLocation(final int quoteId) throws HomequoteSystemException {
		LOG.info("LocationDAO.getLocation -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Location location = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("LocationDAO.getLocation - Connection Successfull");
			//select * from Location where QUOTE_ID = ?
			stmt = conn.prepareStatement(SqlQueries.GET_LOCATION);
			stmt.setInt(1, quoteId);
			LOG.info("LocationDAO.getLocation - SQL Statement: "+SqlQueries.GET_LOCATION+" Value: "+quoteId);
			resultSet = stmt.executeQuery();
			LOG.info("LocationDAO.getLocation - Queried Database");
			location = new Location();
			while (resultSet.next()) {
				location.setQuoteId(resultSet.getInt(1));//QUOTE_ID
				location.setResidenceType(resultSet.getString(2));//RESIDENCE_TYPE
				location.setAddressLine1(resultSet.getString(3));//ADDRESS_LINE_1
				location.setAddressLine2(resultSet.getString(4));//ADDRESS_LINE_2
				location.setCity(resultSet.getString(5));//CITY
				location.setState(resultSet.getString(6));//STATE
				location.setZip(resultSet.getString(7));//ZIP
				location.setResidenceUse(resultSet.getString(8));//RESIDENCE_USE
				location.setUserName(resultSet.getString(9));//USER_NAME
			}
			LOG.info("LocationDAO.getLocation - Location fetched from database: " + location.toString());
		}
		catch(Exception e)
		{
			LOG.error("LocationDAO.getLocation - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("LocationDAO.getLocation -- End");
		return location;
	}

	/**This method fetches a List of Location objects identified by userName by performing a database transaction
	 * @param userName is a String value used to fetch all the QuoteIds from the database
	 * @return A List of Location objects
	 * @throws HomequoteSystemException
	 */
	public List<Location> getQuoteIds(final String userName) throws HomequoteSystemException
	{
		LOG.info("LocationDAO.getQuoteIds -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		ArrayList<Location> locationList = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("LocationDAO.getQuoteIds - Connection Successfull");
			//select QUOTE_ID from Location where USER_NAME = ?
			stmt = conn.prepareStatement(SqlQueries.GET_LOCS_FOR_USER);
			stmt.setString(1, userName);
			LOG.info("LocationDAO.getQuoteIds - SQL Statement: "+SqlQueries.GET_LOCS_FOR_USER+" Value: "+userName);
			resultSet = stmt.executeQuery();
			LOG.info("LocationDAO.getQuoteIds - Queried Database");
			locationList = new ArrayList<Location>();
			Location location = null;
			while (resultSet.next()) {
				location = new Location();
				location.setQuoteId(resultSet.getInt(1));//QUOTE_ID
				location.setResidenceType(resultSet.getString(2));//RESIDENCE_TYPE
				location.setAddressLine1(resultSet.getString(3));//ADDRESS_LINE_1
				location.setAddressLine2(resultSet.getString(4));//ADDRESS_LINE_2
				location.setCity(resultSet.getString(5));//CITY
				location.setState(resultSet.getString(6));//STATE
				location.setZip(resultSet.getString(7));//ZIP
				location.setResidenceUse(resultSet.getString(8));//RESIDENCE_USE
				location.setUserName(resultSet.getString(9));//USER_NAME
				locationList.add(location);
				LOG.info("LocationDAO.getQuoteIds - Fetched Location Added to List: "+location.toString());
			}
			LOG.info("LocationDAO.getQuoteIds - End of List");
		}
		catch(Exception e)
		{
			LOG.error("LocationDAO.getQuoteIds - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("LocationDAO.getQuoteIds -- End");
		return locationList;
	}
}
