/**This Data Access Object class manages database transactions of the Property data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Property;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class PropertyDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG =  Logger.getLogger(PropertyDAO.class);
	
	/**This method fetches a Property object from the database by performing database transaction
	 * @param quoteId is a String value identifying the Property to be fetched
	 * @return A Property object containing QUOTE_ID, MARKET_VALUE, YEAR_BUILT, SQUARE_FOOTAGE, DWELLING_STYLE, ROOF_MATERIAL, GARAGE_TYPE, NUM_FULL_BATHS, NUM_HALF_BATHS, HAS_SWIMMING_POOL
	 * @throws HomequoteSystemException
	 */
	public Property getProperty(final int quoteId) throws HomequoteSystemException
	{
		LOG.info("PropertyDAO.getProperty -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Property property = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PropertyDAO.getProperty - Connection Successfull");
			//select * from Property where QUOTE_ID = ?
			//INSERT INTO Property (QUOTE_ID, MARKET_VALUE, YEAR_BUILT, SQUARE_FOOTAGE, DWELLING_STYLE, ROOF_MATERIAL,
			//GARAGE_TYPE, NUM_FULL_BATHS, NUM_HALF_BATHS, HAS_SWIMMING_POOL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
			stmt = conn.prepareStatement(SqlQueries.GET_PROPERTY);
			stmt.setInt(1, quoteId);
			LOG.info("PropertyDAO.getProperty - SQL Statement: "+SqlQueries.GET_PROPERTY+" Value: "+quoteId);
			resultSet = stmt.executeQuery();
			LOG.info("PropertyDAO.getProperty - Queried Database");
			property = new Property();
			if (resultSet.next()) {
				property.setQuoteId(resultSet.getInt(1));
				property.setMarketValue(resultSet.getInt(2));
				property.setYearBuilt(resultSet.getInt(3));
				property.setSquareFootage(resultSet.getInt(4));
				property.setDwellingStyle(resultSet.getDouble(5));
				property.setRoofMaterial(resultSet.getString(6));
				property.setGarageType(resultSet.getString(7));
				property.setNumFullBaths(resultSet.getInt(8));
				property.setNumHalfBaths(resultSet.getInt(9));
				property.setHasSwimmingPool(Boolean.parseBoolean(resultSet.getString(10)));
				LOG.info("PropertyDAO.getProperty - Property fetched from Database: "+property.toString());
			}
			else
				LOG.info("PropertyDAO.getProperty - Empty");
		}
		catch(Exception e)
		{
			LOG.error("PropertyDAO.getProperty - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PropertyDAO.getProperty -- End");
		return property;
	}
	/**This method saves the Property object information by performing database transaction
	 * @param property is a Property object containing QUOTE_ID, MARKET_VALUE, YEAR_BUILT, SQUARE_FOOTAGE, DWELLING_STYLE, ROOF_MATERIAL, GARAGE_TYPE, NUM_FULL_BATHS, NUM_HALF_BATHS, HAS_SWIMMING_POOL
	 * @throws HomequoteSystemException
	 */
	public void saveProperty(final Property property) throws HomequoteSystemException
	{
		LOG.info("PropertyDAO.saveProperty -- Start");
		LOG.info("PropertyDAO.saveProperty -- Validating data");
		validate(property);
		LOG.info("PropertyDAO.saveProperty -- Validation Complete");
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("PropertyDAO.getProperty - Connection Successfull");
			//INSERT INTO Property (QUOTE_ID, MARKET_VALUE, YEAR_BUILT, SQUARE_FOOTAGE, DWELLING_STYLE, ROOF_MATERIAL,
			//GARAGE_TYPE, NUM_FULL_BATHS, NUM_HALF_BATHS, HAS_SWIMMING_POOL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
			stmt = conn.prepareStatement(SqlQueries.SAVE_PROPERTY);
			stmt.setInt(1, property.getQuoteId());
			stmt.setInt(2, property.getMarketValue());
			stmt.setInt(3, property.getYearBuilt());
			stmt.setInt(4, property.getSquareFootage());
			stmt.setDouble(5, property.getDwellingStyle());
			stmt.setString(6, property.getRoofMaterial());
			stmt.setString(7, property.getGarageType());
			stmt.setInt(8, property.getNumFullBaths());
			stmt.setInt(9, property.getNumHalfBaths());
			stmt.setString(10, Boolean.toString(property.isHasSwimmingPool()));
			LOG.info("PropertyDAO.saveProperty - SQL Statement: "+SqlQueries.SAVE_PROPERTY+" Values: "+property.toString());
			stmt.executeUpdate();
			LOG.info("PropertyDAO.saveProperty - Updated Database");
		}
		catch(Exception e)
		{
			LOG.error("PropertyDAO.saveProperty - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("PropertyDAO.saveProperty -- End");
	}
	
	/**This method validates the values of property before saving to database
	 * @param property is a Property object containing QUOTE_ID, MARKET_VALUE, YEAR_BUILT, SQUARE_FOOTAGE, DWELLING_STYLE, ROOF_MATERIAL, GARAGE_TYPE, NUM_FULL_BATHS, NUM_HALF_BATHS, HAS_SWIMMING_POOL
	 * @throws HomequoteSystemException
	 */
	private void validate(Property property) throws HomequoteSystemException{
		if(property.getMarketValue()<10000 || property.getMarketValue()>10000000) {
			throw new HomequoteSystemException("Bad value for market value");
		}
		LOG.info("PropertyDAO.saveProperty -- Market Value validated");
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY");
		String year = sdf.format(new Date());
		if(property.getYearBuilt()<1950 || property.getYearBuilt()>Integer.parseInt(year)) {
			throw new HomequoteSystemException("Bad value for year");
		}
		LOG.info("PropertyDAO.saveProperty -- Year built validated");
		if(property.getSquareFootage()<300 || property.getSquareFootage()>4000) {
			throw new HomequoteSystemException("Bad value for Square Footage value");
		}
		LOG.info("PropertyDAO.saveProperty -- Square Footage Value validated");
		if(property.getDwellingStyle()!=1 && property.getDwellingStyle()!=1.5 &&
				property.getDwellingStyle()!=2 && property.getDwellingStyle()!=2.5 &&
				property.getDwellingStyle()!=3) {
			throw new HomequoteSystemException("Bad value for Dwelling Style");
		}
		LOG.info("PropertyDAO.saveProperty -- Dwelling Style Value validated");
		if(!property.getRoofMaterial().equals("Concrete") && !property.getRoofMaterial().equals("Clay") &&
				!property.getRoofMaterial().equals("Rubber") &&! property.getRoofMaterial().equals("Steel") &&
				!property.getRoofMaterial().equals("Tin") && !property.getRoofMaterial().equals("Wood")) {
			throw new HomequoteSystemException("Bad value for Roof material");
		}
		LOG.info("PropertyDAO.saveProperty -- Roof Material validated");
		if(!property.getGarageType().equals("Attached") && !property.getGarageType().equals("Detached") &&
				!property.getGarageType().equals("Basement") && !property.getGarageType().equals("Builtin") &&
				!property.getGarageType().equals("None")) {
			throw new HomequoteSystemException("Bad value for Garage Type");
		}
		LOG.info("PropertyDAO.saveProperty -- Garage Type validated");
		if(property.getNumFullBaths()<1 && property.getNumFullBaths()>8) {
			throw new HomequoteSystemException("Bad value for Number of Full Bathrooms");
		}
		LOG.info("PropertyDAO.saveProperty -- Number Full Bathrooms validated");
		if(property.getNumHalfBaths()<0 && property.getNumHalfBaths()>Math.floor(property.getNumFullBaths()/2)) {
			throw new HomequoteSystemException("Bad value for Number of Half Bathrooms");
		}
		LOG.info("PropertyDAO.saveProperty -- Number Half Bathrooms validated");
		if(property.isHasSwimmingPool() && !property.isHasSwimmingPool()) {
			throw new HomequoteSystemException("Bad value for Has Swimming Pool");
		}
		LOG.info("PropertyDAO.saveProperty -- Swimming Pool validated");
	}
}
