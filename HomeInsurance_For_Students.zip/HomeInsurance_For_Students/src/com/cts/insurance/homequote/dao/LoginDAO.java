/**This Data Access Object class manages database transactions of the Login data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.User;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class LoginDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG = Logger.getLogger(LoginDAO.class);
	
	/**This method fetches the User object from the database by performing database transaction
	 * @param userName is a String value identifying the User to be fetched
	 * @return A User object containing USER_NAME, USER_PWD, ADMIN_ROLE
	 * @throws HomequoteSystemException
	 */
	public User getUser(final String userName) throws HomequoteSystemException
	{
		LOG.info("LoginDAO.getUser -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		User user = null;

		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("UserDAO.getUser - Connection Successfull");
			stmt = conn.prepareStatement(SqlQueries.SELECT_USER);
			stmt.setString(1, userName);
			LOG.info("UserDAO.getUser - SQL Statement: "+SqlQueries.SELECT_USER+" Value: "+userName);
			resultSet = stmt.executeQuery();
			LOG.info("UserDAO.getUser - Queried Database");
			if (resultSet.next()) {
				user = new User();
				user.setUserName(resultSet.getString(1));
				user.setPassword(resultSet.getString(2));
				user.setUserRole(resultSet.getString(3));
				LOG.info("UserDAO.getUser - User fetched from database: "+user.toString());
			}
			else
				LOG.info("UserDAO.getUser - Empty");
		}
		catch(Exception e)
		{
			LOG.error("LoginDAO.getUser - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("LoginDAO.getUser -- End");
		return user;
	}
	
	/**This method saves the User object information by performing database transaction 
	 * @param user is a User object containing USER_NAME, USER_PWD, ADMIN_ROLE
	 * @throws HomequoteSystemException
	 */
	public void saveUser(final User user) throws HomequoteSystemException
	{
		LOG.info("LoginDAO.saveUser -- Start");
		LOG.info("LoginDAO.saveUser -- Validating User Data");
		validate(user);
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("UserDAO.saveUser - Connection Successfull");
			stmt = conn.prepareStatement(SqlQueries.SAVE_USER);
			stmt.setString(1, user.getUserName());
			stmt.setString(2, user.getPassword());
			LOG.info("UserDAO.saveUser - SQL Statement"+SqlQueries.SAVE_USER+" Values: ["+user.getUserName()
				+", "+user.getPassword()+"]");
			stmt.executeUpdate();
			LOG.info("UserDAO.saveUser - Database Updated");
		}
		catch(Exception e)
		{
			LOG.error("LoginDAO.saveUser - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("LoginDAO.saveUser -- End");
	}

	/**This method validates the data to be entered into the database
	 * @param user is a User object containing USER_NAME, USER_PWD, ADMIN_ROLE
	 * @throws HomequoteSystemException
	 */
	private void validate(User user) throws HomequoteSystemException{
		if(user.getUserName().matches("[^A-Za-z0-9]") || user.getUserName().length()>19) {
			throw new HomequoteSystemException("User Name violates constraints");
		}
		if(user.getPassword().matches("[^A-Za-z0-9]") || user.getUserName().length()>19) {
			throw new HomequoteSystemException("User Name violates constraints");
		}
	}
	
	/**This method fetches a List of User objects from the database by performing database transaction
	 * @return A List of User Objects
	 * @throws HomequoteSystemException
	 */
	public static List<User> getAllUsers() throws HomequoteSystemException {
		LOG.info("PolicyDAO.getPolicies -- Start");
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		ArrayList<User> userList = null;
		try
		{
			final AbstractDAOFactory daoFactory = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
			conn = daoFactory.getConnection();
			LOG.info("UserDAO.getUsers - Connection Successfull");
			//SELECT * from Policy p, Location l where p.QUOTE_ID= l.QUOTE_ID and l.USER_NAME = ?
			stmt = conn.prepareStatement(SqlQueries.SELECT_ALL_USERS);
			LOG.info("UserDAO.getUsers - SQL Statement: "+SqlQueries.SELECT_ALL_USERS);
			resultSet = stmt.executeQuery();
			LOG.info("UserDAO.getUsers - Queried Database");
			userList = new ArrayList<User>();
			while (resultSet.next()) {
				User user = new User();
				user.setUserName(resultSet.getString("USER_NAME"));
				user.setPassword(resultSet.getString("USER_PWD"));
				user.setUserRole(resultSet.getString("ADMIN_ROLE"));
				userList.add(user);
				LOG.info("UserDAO.getUsers - User Added to List: "+ user.toString());
			}
			LOG.info("UserDAO.getUsers - End of List");
		}
		catch(Exception e)
		{
			LOG.error("UserDAO.getUsers - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} 
		finally
		{
			try
			{
				resultSet.close();
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("UserDAO.getUsers -- End");
		return userList;
	}
}
