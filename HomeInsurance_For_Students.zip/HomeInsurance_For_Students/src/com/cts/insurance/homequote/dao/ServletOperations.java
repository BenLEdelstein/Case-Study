package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class ServletOperations{

	public static void purgeIncomplete(int quoteId, String statement) throws HomequoteSystemException {
		Connection conn = null;
		String sql = null;
		PreparedStatement ps = null;
		
		AbstractDAOFactory adf = new MySqlDAO();
		try {
			conn = adf.getConnection();
			if(statement.equals(HomeInsuranceConstants.INCOMPLETE_LOCATION)) {
				sql = SqlQueries.REMOVE_LOCATION;
			} 
			if(statement.equals(HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO)) {
				sql = SqlQueries.REMOVE_HOMEOWNERINFO;
			}
			ps = conn.prepareStatement(sql);
			ps.setInt(1, quoteId);
			ps.executeUpdate();
		} catch (Exception e) {
			throw new HomequoteSystemException(e.getLocalizedMessage());
		}
		
	}
}
