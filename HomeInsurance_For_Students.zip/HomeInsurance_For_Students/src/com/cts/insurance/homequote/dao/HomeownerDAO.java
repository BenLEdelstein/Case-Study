/**This Data Access Object class manages database transactions of the Homeowner data object
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Homeowner;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;
import com.cts.insurance.homequote.util.SqlQueries;

public class HomeownerDAO {
	
	/**
	 * Logger
	 */
	private final static Logger LOG = Logger.getLogger(HomeownerDAO.class);

	/**This method saves the Homeowner object information by performing database transaction 
	 * @param homeowner is a Homeowner object containing QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS
	 * @throws HomequoteSystemException
	 */
	public void saveHomeowner(final Homeowner homeowner) throws HomequoteSystemException
	{
		LOG.info("HomeownerDAO.saveHomeowner -- Start");
		LOG.info("HomeownerDAO.saveHomeowner -- Validating Homeowner data");
		try {
			validate(homeowner);
		} catch (ParseException e1) {
			throw new HomequoteSystemException(e1.getLocalizedMessage());
		}
		LOG.info("HomeownerDAO.saveHomeowner -- Validation Complete");
		Connection conn = null;
		PreparedStatement stmt = null;
		
		final AbstractDAOFactory aDF = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
		try {
			conn = aDF.getConnection();
			LOG.info("HomeownerDAO.saveHomeowner - Connection Successfull");
			stmt = conn.prepareStatement(SqlQueries.SAVE_HOMEOWNER);
			//INSERT INTO HomeownerInfo (QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS)
			//(int, String, String, String, String, String, String)
			stmt.setInt(1, homeowner.getQuoteId());
			stmt.setString(2, homeowner.getFirstName());
			stmt.setString(3,  homeowner.getLastName());
			stmt.setString(4, homeowner.getDob());
			stmt.setString(5, homeowner.getIsRetired());
			stmt.setString(6, homeowner.getSsn());
			stmt.setString(7, homeowner.getEmailAddress());
			LOG.info("HomeownerDAO.saveHomeowner - SQL Statement: "+SqlQueries.SAVE_HOMEOWNER
					+" VALUES : "+homeowner.toSafeString());
			stmt.executeUpdate();
			LOG.info("HomeownerDAO.saveHomeowner - Updated Database");
		} catch (Exception e) {
			LOG.error("HomeownerDAO.saveHomeowner - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}
		LOG.info("HomeownerDAO.saveHomeowner -- End");
	}
	
	/**This method validates all home owner data values to conform to database constraints
	 * @param homeowner is the homeowner object containing QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS
	 * @throws ParseException 
	 * @throws HomequoteSystemException
	 */
	private void validate(Homeowner homeowner)throws HomequoteSystemException, ParseException {
		if(homeowner.getFirstName().matches("[^A-Za-z0-9]") || homeowner.getFirstName().length()>30) {
			throw new HomequoteSystemException("First Name is invalid");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked First Name");
		if(homeowner.getLastName().matches("[^A-Za-z0-9]") || homeowner.getLastName().length()>30) {
			throw new HomequoteSystemException("Last Name is invalid");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked Last Name");
		if(!homeowner.getDob().matches("^[0-9]{4}-[0-9]{2}-[0-9]{2}")){
			throw new HomequoteSystemException("DOB is wrong format");
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dob = sdf.parse(homeowner.getDob());
		String date = sdf.format(new Date());
		sdf.parse(date);
		Calendar cal = sdf.getCalendar();
		cal.add(Calendar.YEAR, -18);
		Date eighteen = cal.getTime();
		if(dob.compareTo(eighteen)>=0) {
			throw new HomequoteSystemException("DOB shows less than 18 years of age");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked DOB"+sdf.format(dob)+" "+sdf.format(eighteen));
		if(!homeowner.getIsRetired().equals("Yes") && !homeowner.getIsRetired().equals("No")) {
			throw new HomequoteSystemException("Bad value for Is_Retired");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked Is Retired");
		if(homeowner.getSsn().matches("[^0-9]") || homeowner.getSsn().length()!=9) {
			throw new HomequoteSystemException("Bad value for SSN");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked SSN");
		if(homeowner.getEmailAddress().length()>50 || !homeowner.getEmailAddress().matches("^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$")) {
			throw new HomequoteSystemException("Bad value for email");
		}
		LOG.info("HomeownerDAO.saveHomeowner - Checked Email");
	}
		


	/**This method gets Homeowner object by performing database transaction
	 * @param quoteId is a String value of the QuoteId used to fetch the Homeowner object
	 * @return A Homeowner object containing QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS
	 * @throws HomequoteSystemException
	 */
	public Homeowner getHomeowner(final int quoteId) throws HomequoteSystemException
	{
		LOG.info("HomeownerDAO.getHomeowner -- Start");
		Connection conn = null;
		Homeowner homeowner = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;

		final AbstractDAOFactory aDF = AbstractDAOFactory.getDaoFactory(HomeInsuranceConstants.MYSQL);
		
		try {
			conn = aDF.getConnection();
			LOG.info("HomeownerDAO.getHomeowner - Connection Successfull");
			stmt = conn.prepareStatement(SqlQueries.GET_HOMEOWNER);
			LOG.info("HomeownerDAO.getHomeowner - SQL Statement: "+SqlQueries.GET_HOMEOWNER +" Value: "+quoteId);
			stmt.setInt(1, quoteId);
			resultSet = stmt.executeQuery();
			if(resultSet.next()) {
				homeowner = new Homeowner();
				//(QUOTE_ID, FIRST_NAME, LAST_NAME, DOB, IS_RETIRED, SSN, EMAIL_ADDRESS)
				homeowner.setQuoteId(quoteId);
				homeowner.setFirstName(resultSet.getString("FIRST_NAME"));
				homeowner.setLastName(resultSet.getString("LAST_NAME"));
				homeowner.setDob(resultSet.getString("DOB"));
				homeowner.setIsRetired(resultSet.getString("IS_RETIRED"));
				homeowner.setSsn(resultSet.getString("SSN"));
				homeowner.setEmailAddress(resultSet.getString("EMAIL_ADDRESS"));
				LOG.info("HomeownerDAO.getHomeowner - Homeowner fetched from database: "+homeowner.toSafeString());
			}
			else
				LOG.info("HomeownerDAO.getHomeowner - Empty");
		} catch (Exception e) {
			LOG.error("HomeownerDAO.getHomeowner - Exception! "+e.getLocalizedMessage());
			throw new HomequoteSystemException(e.getLocalizedMessage());
		} finally {
			try {
				resultSet.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				LOG.error("Exception while trying to close Connection : " + e.getLocalizedMessage() );
			}
		}	
		LOG.info("HomeownerDAO.getHomeowner -- END");
		return homeowner; //return Object
	}

}
