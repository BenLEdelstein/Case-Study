/**AbstractDAOFactory class provides getDaoFactory method which constructs an instance of MySqlDAO and the abstract method getConnection
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public abstract class AbstractDAOFactory {

	/**This method constructs an instance of MySqlDAO class given the String input HomeInsuranceConstants.MySQL
	 * @param value is a String. If matched to HomeInsuranceConstants.MySQL a new MySqlDAO instance is initialized
	 * @return An AbstractDAOFactory object
	 */
	public static AbstractDAOFactory getDaoFactory(final String value) {
		AbstractDAOFactory abstractDao = null;
		if (value != null && value.equals(HomeInsuranceConstants.MYSQL)) {
			abstractDao = new MySqlDAO();
		}
		return abstractDao;
	}

	/**This method fetches connection properties from com/cts/insurance/homequote/resources/db.properties
	 * It sets the driver and initializes a connection with the url, username and password fetched
	 * returns the initialized Connection object from the AbstractDAOFactory
	 * @return An initialized Connection object
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws SQLException
	 */
	public abstract Connection getConnection() throws ClassNotFoundException,
			IOException, SQLException;
}
