/**
 * IHomeInsuranceConstants
 * Holds the constants for HomeInsuranceQuote Application
 * 
 * @author Cognizant
 * @contact Cognizant
 * @version 1.0
 */
package com.cts.insurance.homequote.util;

public final class HomeInsuranceConstants
{
	/**
	 * Request Parameters
	 */
	public static final String ACTION = "action";
	public static final String REQUEST_SOURCE = "requestSource";
	
	/**
	 * Request Parameters: Login
	 */
	public static final String EXISTING_USER = "ExistingUser";
	public static final String NEW_USER = "newUser";
	public static final String SEARCH_USER = "searchUser";
	public static final String LOGOUT = "logout";
	public static final String SELECTED_USER = "selectedUser";
	public static final String PASSWORD = "password";
	public static final String ADMIN = "Admin";
	public static final String USER = "User";
	public static final String POLICY_LIST = "policyList";
	
	/**
	 *Request Parameters: Location Page 
	 */
	 public static final String RESIDENCE_TYPE = "residenceType";
	 public static final String ADDRESS_LINE_1 = "addressLine1";
	 public static final String ADDRESS_LINE_2 = "addressLine2";
	 public static final String CITY	= "city";
	 public static final String STATE = "state";
	 public static final String ZIP = "zip";
	 public static final String RESIDENCE_USE = "residenceUse";
	 public static final String LOCATION_LIST = "locationList";
	
	/**
	 * Request Parameters: HomeownerInfo Page
	 */
	 public static final String FIRST_NAME = "firstName";
	 public static final String LAST_NAME = "lastName";
	 public static final String DATE_OF_BIRTH = "dob";
	 public static final String IS_RETIRED = "isRetired";
	 public static final String SSN = "ssn";
	 public static final String EMAIL_ADDRESS = "emailAddress";
	
	/**
	 * Request Parameters: Property Page
	 */
	 public static final String MARKET_VALUE = "marketValue";
	 public static final String YEAR_BUILT = "yearBuilt";
	 public static final String SQUARE_FOOTAGEG = "squareFootage";
	 public static final String DWELLING_STYLE = "dwellingStyle";
	 public static final String ROOF_MATERIAL = "roofMaterial";
	 public static final String GARAGE_TYPE = "garageType";
	 public static final String NUM_FULL_BATHS = "numFullBaths";
	 public static final String NUM_HALF_BATHS = "numHalfBaths";
	 public static final String HAS_SWIMMING_POOL = "hasSwimmingPool";
	
	 /**
	  * Request Parameters: Policy Page
	  */
	 public static final String POLICY = "policy";
	 public static final String POLICY_EFFECTIVE_DATE = "policyEffDate";
	 public static final String ACTION_SELECTED = "actionSelected";
	 public static final String POLICY_SELECTED = "policySelected";
	 public static final String SUCCESS_MESSAGE = "successMsg";
	 public static final String RENEW_ACTION = "Renew";
	 public static final String CANCEL_ACTION = "Cancel";
	 public static final String CHANGE_ACTION = "change";
	 
	 /**
	  * Request Parameters: QuoteSummary Page
	  */
	 public static final String GET_QUOTES = "getQuotes";
	 public static final String QUOTE_ID_SELECTED = "quoteIdSelected";
	 
	 /**
	  * DAO values
	  */
	 public static final String MYSQL = "MySQL";
	 public static final String CANCEL = "Cancel";
	 public static final String RENEW = "Renew";
	
	 /**
	  * Quote constants: Rate - cost of home insurance per exposure
	  */
	 public static final int RATE = 5;
	 public static final int EXPOSURE_UNITS = 1000;
	 public static final int CONS_COST_PER_SF = 120;
	 public static final int MEDICAL_EXPENSE = 5000;
	/**
	 * Success forward page
	 */
	 public static final String WELCOME_PAGE = "/welcome.jsp";
	 public static final String GET_STARTED_PAGE = "/getStarted.jsp";
	 public static final String SEARCH_USER_PAGE = "/searchUser.jsp";
	 public static final String LOCATION_PAGE = "/location.jsp";
	 public static final String HOMEOWNER_INFO_PAGE = "/homeownerInfo.jsp";
	 public static final String PROPERTY_PAGE = "/property.jsp";
	 public static final String QUOTE_PAGE = "/quote.jsp";
	 public static final String QUOTE_SUMMARY_PAGE = "/quoteSummary.jsp";
	 public static final String RETRIEVE_QUOTE_PAGE = "/retrieveQuote.jsp";
	 public static final String CONFIRM_PAGE = "/confirmation.jsp";
	 public static final String POLICY_DETAILS_PAGE = "/policyDetails.jsp";
	 public static final String POLICY_PAGE = "/policy.jsp";
	 public static final String LOGOUT_PAGE = "/logout.jsp";
	 
	/**
	 * Error page forward
	 */
	 public static final String ERROR ="/error.jsp";
	 public static final String MESSAGE = "message";
	
	/**
	 * Policy Status
	 */
	 public static final String STATUS_ACTIVE = "ACTIVE";
	 public static final String STATUS_CANCELLED = "CANCELLED";
	 public static final String STATUS_RENEWED = "RENEWED";
	 
	/**
	 * Session Attributes
	 */
	 public static final String USER_NAME = "userName";
	 public static final String LOCATION = "location";
	 public static final String HOMEOWNER = "homeowner";
	 public static final String PROPERTY = "property";
	 public static final String ROLE = "Role";
	 public static final String QUOTE_ID = "quoteId";
	 public static final String QUOTE = "quote";
	 
	 public static final String INCOMPLETE_LOCATION = "incompleteLocation";
	 public static final String INCOMPLETE_HOMEOWNERINFO = "incompleteHomeownerInfo";
	 
	 // PRIVATE //

	  /**
	   The caller references the constants using <tt>HomeInsuranceConstants.EMPTY_STRING</tt>, 
	   and so on. Thus, the caller should be prevented from constructing objects of 
	   this class, by declaring this private constructor. 
	  */
	  private HomeInsuranceConstants(){
	    //this prevents even the native class from 
	    //calling this constructor as well :
	    throw new AssertionError();
	  }
}
