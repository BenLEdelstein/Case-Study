/**
 * LogInitializer is a servlet that initializes the log4j Logger
 * with properties from \WEB-INF\log4j.properties
 * The Logger is available to other servlets by the LOG constant
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.log;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.PropertyConfigurator;

public class LogInitializer extends HttpServlet {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The Constant LOG. */
	private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger
			.getLogger(LogInitializer.class);

	/**LoggerInitializer servlet initialize method employs log4j Logger
	 * The logger is initialized using properties from \WEB-INF\log4j.properties
	 * @param config is ServletConfig object used to fetch the real path of the log4j.properties file
	 * @throws ServletException
	 */
	public void init(final ServletConfig config)
			throws ServletException {
		final String realPath = config.getServletContext()
				.getRealPath("/");
		final String log4jFile = realPath+"/WEB-INF/log4j.properties";
		PropertyConfigurator.configure(log4jFile);
		LOG.info("Application Initialized");
	}
}
