/**
 * HomequoteBusinessException
 * Exception class for Business exception handling
 * These Exceptions are thrown at the Business Object (BO) class level
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.exception;

public class HomequoteBusinessException extends Exception{
	
    /**
	 * Serialized
	 */
	private static final long serialVersionUID = 1L;

	/**Exception constructor takes error message as String message parameter
	 * @param message is a String containing the error message
	 */
	public HomequoteBusinessException(final String message) {
        super(message);
    }

}
