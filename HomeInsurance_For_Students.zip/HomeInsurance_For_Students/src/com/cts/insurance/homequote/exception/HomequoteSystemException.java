/**
 * HomequoteSystemException
 * Exception class for System exception handling
 * These Exceptions are thrown at the Data Access Object (DAO) class level
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.exception;

public class HomequoteSystemException extends Exception {

    /**
	 * Serialized
	 */
	private static final long serialVersionUID = 1L;

	/**Exception constructor takes error message as String message parameter
	 * @param message is a String containing the error message
	 */
	public HomequoteSystemException(final String message) {
        super(message);
    }
}
