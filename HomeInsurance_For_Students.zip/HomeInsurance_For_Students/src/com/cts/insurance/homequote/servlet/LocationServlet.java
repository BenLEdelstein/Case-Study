/**LocationServlet class is a servlet that manages the information received from the location.jsp page form
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.LocationBO;
import com.cts.insurance.homequote.model.Location;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class LocationServlet extends HttpServlet{
	
	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Logger
	 */
	private static final Logger LOG = Logger.getLogger(LocationServlet.class);
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {
		LOG.info("LocationServlet.doPost -- Start");
		try {
			final HttpSession session = request.getSession();
			String forward = null;
			final String userName = (String)session.getAttribute(HomeInsuranceConstants.USER_NAME);
			if(userName!=null) {
				LOG.info("LocationServlet.doPost -- User Name: "+userName);
				if(session.getAttribute(HomeInsuranceConstants.LOCATION)==null) {
					LOG.info("LocationServlet.doPost - Session Attribute Location Not Found");
					final Location location = new Location();
					//(QUOTE_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, STATE, ZIP, RESIDENCE_USE, USER_NAME)
					location.setResidenceType(request.getParameter(HomeInsuranceConstants.RESIDENCE_TYPE));
					LOG.info("Location residenceType set as "+location.getResidenceType());
					location.setAddressLine1(request.getParameter(HomeInsuranceConstants.ADDRESS_LINE_1));
					LOG.info("Location addressLine1 set as "+location.getAddressLine1());
					location.setAddressLine2(request.getParameter(HomeInsuranceConstants.ADDRESS_LINE_2));
					LOG.info("Location addressLine2 set as "+location.getAddressLine2());
					location.setCity(request.getParameter(HomeInsuranceConstants.CITY));
					LOG.info("Location city set as "+location.getCity());
					location.setState(request.getParameter(HomeInsuranceConstants.STATE));
					LOG.info("Location state set as "+location.getState());
					location.setZip(request.getParameter(HomeInsuranceConstants.ZIP));
					LOG.info("Location zip set as "+location.getZip());
					location.setResidenceUse(request.getParameter(HomeInsuranceConstants.RESIDENCE_USE));
					LOG.info("Location residenceUse set as "+location.getResidenceUse());
					location.setUserName(userName);
					LOG.info("Location userName set as "+location.getUserName());
					
					LocationBO locationBO = new LocationBO();
					location.setQuoteId(locationBO.saveHomeLocation(location));
					LOG.info("Location saved to database");
					session.setAttribute(HomeInsuranceConstants.INCOMPLETE_LOCATION, location.getQuoteId());
					LOG.info("Incomplete form state saved to database");
					session.setAttribute(HomeInsuranceConstants.LOCATION, location);
					LOG.info("Location saved to session");
				}
				else {
					final Location location = (Location)session.getAttribute(HomeInsuranceConstants.LOCATION);
					LOG.info("Session already exists - Location Object: "+location.toString());
				}
				session.setAttribute(HomeInsuranceConstants.REQUEST_SOURCE, HomeInsuranceConstants.LOCATION_PAGE);
				LOG.info("LocationServlet.doPost -- Set Request Source as Location");
				forward = HomeInsuranceConstants.HOMEOWNER_INFO_PAGE;
			} else {
				LOG.info("LocationServlet.doPost -- No User Found");
				request.setAttribute(HomeInsuranceConstants.MESSAGE, "Session Interrupted: Please login again.");
				forward = HomeInsuranceConstants.WELCOME_PAGE;
			}
			LOG.info("LocationServlet.doPost -- Forwarding to: "+forward);
			LOG.info("LocationServlet.doPost -- End");
			final RequestDispatcher rd = request.getRequestDispatcher(forward) ;
			rd.forward(request, response);
			
		}catch (Exception e) {
			LOG.error("Exception occurred in method LocationServlet.doPost :: "
					+ e);
			request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(request, response);
		}
	}
}