/**
 * Servlet for capturing Policy information
 * 
 * @author Cognizant
 * @contact Cognizant
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.PolicyBO;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.model.Policy;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class PolicyServlet extends HttpServlet{
	
	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Logger
	 */
	private static final Logger LOG = Logger.getLogger(PolicyServlet.class);

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {

		LOG.info("PolicyServlet.doPost -- Start");
		try {
			//Get Request Parameters
			String forwardPage = null;
			final String action =  request.getParameter(HomeInsuranceConstants.ACTION);
			LOG.info("PolicyServlet.doPost - Action Value: "+action);
			final PolicyBO policyBO = new PolicyBO();
			if(request.getSession().getAttribute(HomeInsuranceConstants.USER_NAME)==null && request.getSession().getAttribute(HomeInsuranceConstants.ROLE)==null) {
				request.setAttribute(HomeInsuranceConstants.MESSAGE, "Session Interrupted: Please login again.");
				forwardPage=HomeInsuranceConstants.WELCOME_PAGE;
			}
			else if(action == null || !action.equals(HomeInsuranceConstants.CHANGE_ACTION))
			{
				LOG.info("PolicyServlet.doPost - Not Changing Policy");
				final HttpSession session = request.getSession();
				final String policyEffDate = request.getParameter(HomeInsuranceConstants.POLICY_EFFECTIVE_DATE);
				LOG.info("PolicyServlet.doPost - Policy Effective Date Value: "+policyEffDate);
				final int quoteId = ((Integer)session.getAttribute(HomeInsuranceConstants.QUOTE_ID)).intValue();
				LOG.info("PolicyServlet.doPost - QuoteId Value: "+quoteId);
				try {
					request.setAttribute(HomeInsuranceConstants.POLICY, policyBO.savePolicy(quoteId, policyEffDate, 1));
					LOG.info("PolicyServlet.doPost - Policy Saved in Request Attribute: "+HomeInsuranceConstants.POLICY);
					forwardPage = HomeInsuranceConstants.CONFIRM_PAGE;
				} catch (HomequoteBusinessException e) {
					if(e.getLocalizedMessage().contains("unique")) {
						request.setAttribute(HomeInsuranceConstants.MESSAGE, "Quote has already been purchased");
						List<Policy> policy = new ArrayList<Policy>();
						policy.add(policyBO.getPolicy(quoteId));
						request.setAttribute(HomeInsuranceConstants.POLICY_LIST, policy);
						forwardPage=HomeInsuranceConstants.POLICY_DETAILS_PAGE;
					}
					else
						throw new HomequoteBusinessException(e.getLocalizedMessage());
				}
			}
			else
			{
				LOG.info("PolicyServlet.doPost - Changing Policy");
				final String actionSelected =  request.getParameter(HomeInsuranceConstants.ACTION_SELECTED);
				LOG.info("PolicyServlet.doPost - Action Selected Value: "+actionSelected);
				final String policyKey =  request.getParameter(HomeInsuranceConstants.POLICY_SELECTED);
				LOG.info("PolicyServlet.doPost - Policy Key Value: "+policyKey);
				if(actionSelected.equals(HomeInsuranceConstants.RENEW_ACTION))
				{
					LOG.info("PolicyServlet.doPost - Renewing");
					request.setAttribute(HomeInsuranceConstants.POLICY, policyBO.renewPolicy(policyKey));
					LOG.info("PolicyServlet.doPost - Saved Value in request"+HomeInsuranceConstants.POLICY
							+": "+request.getAttribute(HomeInsuranceConstants.POLICY));
					request.setAttribute(HomeInsuranceConstants.SUCCESS_MESSAGE, "Policy Renewed Successfully");
					LOG.info("PolicyServlet.doPost - Saved Value in request"+HomeInsuranceConstants.SUCCESS_MESSAGE
							+": "+request.getAttribute(HomeInsuranceConstants.SUCCESS_MESSAGE));
				}
				else if(actionSelected.equals(HomeInsuranceConstants.CANCEL_ACTION))
				{
					LOG.info("PolicyServlet.doPost - Cancelling");
					request.setAttribute(HomeInsuranceConstants.POLICY, policyBO.cancelPolicy(policyKey));
					LOG.info("PolicyServlet.doPost - Saved Value in request"+HomeInsuranceConstants.POLICY
							+": "+request.getAttribute(HomeInsuranceConstants.POLICY));
					request.setAttribute(HomeInsuranceConstants.SUCCESS_MESSAGE, "Policy Cancelled Successfully");
					LOG.info("PolicyServlet.doPost - Saved Value in request"+HomeInsuranceConstants.SUCCESS_MESSAGE
							+": "+request.getAttribute(HomeInsuranceConstants.SUCCESS_MESSAGE));
				}
				else 
					LOG.info("PolicyServlet.doPost - No Renew or Cancel of Policy Performed");
				forwardPage = HomeInsuranceConstants.POLICY_PAGE;
			}
			LOG.info("PolicyServlet.doPost -- Forwarding to: "+forwardPage);
			LOG.info("PolicyServlet.doPost -- End");
			final RequestDispatcher dispatcher = request.getRequestDispatcher(forwardPage);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception occurred in method PropertyServlet.doPost :: "
					+ e);
			request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(request, response);
		}
	}
}