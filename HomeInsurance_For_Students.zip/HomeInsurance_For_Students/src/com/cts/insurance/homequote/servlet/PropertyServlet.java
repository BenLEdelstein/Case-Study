/**
 * Servlet for capturing Property information
 * 
 * @author Cognizant
 * @contact Cognizant
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.PropertyBO;
import com.cts.insurance.homequote.bo.QuoteBO;
import com.cts.insurance.homequote.model.Homeowner;
import com.cts.insurance.homequote.model.Location;
import com.cts.insurance.homequote.model.Property;
import com.cts.insurance.homequote.model.Quote;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class PropertyServlet extends HttpServlet{
	
	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 1L;
	
	private static 	final Logger LOG = Logger.getLogger(PropertyServlet.class);
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {
		LOG.info("PropertyServlet.doPost -- Start");
		String forward = null;
		try {
				final HttpSession session = request.getSession();
				final String userName = (String)session.getAttribute(HomeInsuranceConstants.USER_NAME);
				LOG.info("PropertyServlet.doPost -- User Name: "+userName);
				final String requestSource = (String)session.getAttribute(HomeInsuranceConstants.REQUEST_SOURCE);
				if(userName!=null && requestSource!=null && requestSource.equals(HomeInsuranceConstants.HOMEOWNER_INFO_PAGE)) {				
					if(session.getAttribute(HomeInsuranceConstants.PROPERTY) == null)
					{
						LOG.info("PropertyServlet.doPost -- Session Attribute Property Not Found");
						//Get Request Parameters and set it to the data object
						final Property property = new Property();
						property.setMarketValue(Integer.parseInt(request.getParameter(HomeInsuranceConstants.MARKET_VALUE)));
						LOG.info("PropertyServlet.doPost -- Fetched Market Value: "+property.getMarketValue());
						property.setYearBuilt(Integer.parseInt(request.getParameter(HomeInsuranceConstants.YEAR_BUILT)));
						LOG.info("PropertyServlet.doPost -- Fetched Year Build: "+property.getYearBuilt());
						property.setSquareFootage(Integer.parseInt(request.getParameter(HomeInsuranceConstants.SQUARE_FOOTAGEG)));
						LOG.info("PropertyServlet.doPost -- Fetched Square Footage: "+property.getSquareFootage());
						property.setDwellingStyle(Double.parseDouble(request.getParameter(HomeInsuranceConstants.DWELLING_STYLE)));
						LOG.info("PropertyServlet.doPost -- Fetched Dwelling Style: "+property.getDwellingStyle());
						property.setRoofMaterial(request.getParameter(HomeInsuranceConstants.ROOF_MATERIAL));
						LOG.info("PropertyServlet.doPost -- Fetched Roof Material: "+property.getRoofMaterial());
						property.setGarageType(request.getParameter(HomeInsuranceConstants.GARAGE_TYPE));
						LOG.info("PropertyServlet.doPost -- Fetched Garage Type: "+property.getGarageType());
						property.setNumFullBaths(Integer.parseInt(request.getParameter(HomeInsuranceConstants.NUM_FULL_BATHS)));
						LOG.info("PropertyServlet.doPost -- Fetched Number of Full Baths: "+property.getNumFullBaths());
						property.setNumHalfBaths(Integer.parseInt(request.getParameter(HomeInsuranceConstants.NUM_HALF_BATHS)));
						LOG.info("PropertyServlet.doPost -- Fetched Number of Half Baths: "+property.getNumHalfBaths());
						property.setHasSwimmingPool(Boolean.parseBoolean(request.getParameter(HomeInsuranceConstants.HAS_SWIMMING_POOL)));
						LOG.info("PropertyServlet.doPost -- Fetched Has Swimming Pool: "+(property.isHasSwimmingPool()?"True":"False"));
						if(session.getAttribute(HomeInsuranceConstants.LOCATION) != null)
						{
							LOG.info("PropertyServlet.doPost -- Session Attribute Location Found");
							final Location location = (Location)session.getAttribute(HomeInsuranceConstants.LOCATION);
							LOG.info("PropertyServlet.doPost -- Fetched Location Object: "+location.toString());
							property.setQuoteId(location.getQuoteId());
							LOG.info("PropertyServlet.doPost -- Fetched QuoteId: "+location.getQuoteId());
						}
						else {
							LOG.info("PropertyServlet.doPost -- Session Attribute Location Not Found");
						}
						final PropertyBO propertyBo = new PropertyBO();
						propertyBo.saveProperty(property);
						LOG.info("PropertyServlet.doPost -- Property Saved to Database");
						session.setAttribute(HomeInsuranceConstants.PROPERTY, property);
						LOG.info("PropertyServlet.doPost -- Property Saved to Session");
						
						final Homeowner homeowner = (Homeowner)session.getAttribute(HomeInsuranceConstants.HOMEOWNER);
						LOG.info("PropertyServlet.doPost -- Homeowner Fetched from Session: "+homeowner.toSafeString());
						final Location location = (Location)session.getAttribute(HomeInsuranceConstants.LOCATION);
						LOG.info("PropertyServlet.doPost -- Location Fetched from Session: "+location.toString());
						
						final QuoteBO quoteBO = new QuoteBO();
						final Quote quote = quoteBO.calculateQuote(location, homeowner, property);
						LOG.info("PropertyServlet.doPost -- Quote Calculated: "+quote.toString());
						quoteBO.saveQuote(quote);
						LOG.info("PropertyServlet.doPost -- Quote Saved to Database");
						request.setAttribute(HomeInsuranceConstants.QUOTE, quote);
						LOG.info("PropertyServlet.doPost -- Quote Saved to Session");
						session.removeAttribute(HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO);
						session.removeAttribute(HomeInsuranceConstants.INCOMPLETE_LOCATION);
						LOG.info("PropertyServlet.doPost -- Forms complete");
						session.setAttribute(HomeInsuranceConstants.REQUEST_SOURCE, HomeInsuranceConstants.PROPERTY_PAGE);
						forward = HomeInsuranceConstants.QUOTE_PAGE;
					}
				}
				else {
					LOG.info("PropertyServlet.doPost -- Bad Route");
					forward = HomeInsuranceConstants.WELCOME_PAGE;
					request.setAttribute(HomeInsuranceConstants.MESSAGE, "Session Interrupted: Session was closed, please log back in.");
				}
				LOG.info("PropertyServlet.doPost -- Forwarding to: "+forward);
				LOG.info("PropertyServlet.doPost -- End");
				final RequestDispatcher dispatcher = request.getRequestDispatcher(forward);
				dispatcher.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception occurred in method PropertyServlet.doPost :: "
					+ e);
			request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(request, response);
		}
	}
}