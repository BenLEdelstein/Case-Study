/**QuoteSummaryServlet class is a servlet that manages the information received from the retrieveQuote.jsp page form
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.HomeownerBO;
import com.cts.insurance.homequote.bo.LocationBO;
import com.cts.insurance.homequote.bo.LoginBO;
import com.cts.insurance.homequote.bo.PropertyBO;
import com.cts.insurance.homequote.bo.QuoteBO;
import com.cts.insurance.homequote.model.Location;
import com.cts.insurance.homequote.model.User;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class QuoteSummaryServlet extends HttpServlet{
	
	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Logger
	 */
	private static final Logger LOG = Logger.getLogger(QuoteSummaryServlet.class);

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {
		LOG.info("QuoteSummaryServlet.doPost -- Start");
		try {
			//Get Request Parameters
			final String action = request.getParameter(HomeInsuranceConstants.ACTION);
			LOG.info("QuoteSummaryServlet.doPost -- Action Value: "+action);
			String forward = null;
			final HttpSession session = request.getSession();
			if(session.getAttribute(HomeInsuranceConstants.USER_NAME)==null && session.getAttribute(HomeInsuranceConstants.ROLE)==null) {
				request.setAttribute(HomeInsuranceConstants.MESSAGE, "Session Interrupted: Please login again.");
				forward = HomeInsuranceConstants.WELCOME_PAGE;
			}
			else if(action.equals(HomeInsuranceConstants.GET_QUOTES))
			{
				LOG.info("QuoteSummaryServlet.doPost -- Getting Quotes");
				final String userName = (String)session.getAttribute(HomeInsuranceConstants.USER_NAME);
				final String role = (String)session.getAttribute(HomeInsuranceConstants.ROLE);
				if(userName!=null && (role==null || !role.equals(HomeInsuranceConstants.ADMIN))) {
					LOG.info("QuoteSummaryServlet.doPost -- userName Value: "+userName);
					final LocationBO locationBO = new LocationBO();
					final List<Location> locationList = locationBO.getQuoteIds(userName);
					LOG.info("QuoteSummaryServlet.doPost -- Fetched List of"+locationList.size()+"QuoteIds");
					request.setAttribute("locationList", locationList);
					LOG.info("QuoteSummaryServlet.doPost -- Request Attribute Set");
				}
				else if(role!=null && role.equals(HomeInsuranceConstants.ADMIN)){
					LOG.info("QuoteSummaryServlet.doPost -- Fetching all quotes");
					List<Location> quoteList = new ArrayList<Location>();
					List<User> users = LoginBO.getAllUsers();
					LOG.info("QuoteSummaryServlet.doPost -- Fetching locationList for number of users: "+users.size());
					for(User user:users) {
						LOG.info("QuoteSummaryServlet.doPost -- Fetching quotes for user: "+user);
						LocationBO locationBO = new LocationBO();
						List<Location> locationList = locationBO.getQuoteIds(user.getUserName());
						LOG.info("QuoteSummaryServlet.doPost -- Fetched List of"+locationList.size()+"QuoteIds");
						quoteList.addAll(locationList);
					}
					request.setAttribute(HomeInsuranceConstants.LOCATION_LIST, quoteList);
					LOG.info("QuoteSummaryServlet.doPost -- Request Attribute Set");					
				}
				forward = HomeInsuranceConstants.RETRIEVE_QUOTE_PAGE;
			}
			else
			{
				LOG.info("QuoteSummaryServlet.doPost -- Setting Objects in Session");
				final int quoteId = Integer.parseInt(request.getParameter(HomeInsuranceConstants.QUOTE_ID_SELECTED));
				session.setAttribute(HomeInsuranceConstants.QUOTE_ID, Integer.valueOf(quoteId));
				LOG.info("QuoteSummaryServlet.doPost -- Saved to Session QuoteId: "+quoteId);
				final LocationBO locationBO = new LocationBO();
				request.setAttribute(HomeInsuranceConstants.LOCATION, locationBO.getHomeLocation(quoteId));
				LOG.info("QuoteSummaryServlet.doPost -- Saved to Session Location");
				final HomeownerBO homeownerBO = new HomeownerBO();
				request.setAttribute(HomeInsuranceConstants.HOMEOWNER, homeownerBO.getHomeownerInfo(quoteId));
				LOG.info("QuoteSummaryServlet.doPost -- Saved to Session Homeowner");
				final PropertyBO propertyBO = new PropertyBO();
				request.setAttribute(HomeInsuranceConstants.PROPERTY, propertyBO.getProperty(quoteId));
				LOG.info("QuoteSummaryServlet.doPost -- Saved to Session Property");
				final QuoteBO quoteBO = new QuoteBO();
				session.setAttribute(HomeInsuranceConstants.QUOTE, quoteBO.getQuote(quoteId));
				LOG.info("QuoteSummaryServlet.doPost -- Saved to Session Quote");
				forward = HomeInsuranceConstants.QUOTE_SUMMARY_PAGE;
			}
			LOG.info("QuoteSummaryServlet.doPost -- Forwarding to: "+forward);
			LOG.info("QuoteSummaryServlet.doPost -- End");			
			final RequestDispatcher dispatcher = request.getRequestDispatcher(forward);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception occurred in method PropertyServlet.doPost :: "
					+ e);
			request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(request, response);
		}
	}
}