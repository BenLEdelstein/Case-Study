/**LoginServlet class is a servlet that manages the information received from the welcome.jsp, newUser.jsp, searchUser.jsp and logout.jsp page forms
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.LoginBO;
import com.cts.insurance.homequote.bo.PolicyBO;
import com.cts.insurance.homequote.dao.ServletOperations;
import com.cts.insurance.homequote.exception.HomequoteBusinessException;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Policy;
import com.cts.insurance.homequote.model.User;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class LoginServlet extends HttpServlet {

	/**
	 * Serialized
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Logger
	 */
	private static final Logger LOG = Logger.getLogger(LoginServlet.class);	
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {
		HttpSession session = request.getSession();
		LOG.info("LoginServlet.doPost -- Start");
		final String action = request.getParameter(HomeInsuranceConstants.ACTION);
		LOG.info("LoginServlet.doPost -- Action Value: "+action);
		if(!action.equals(HomeInsuranceConstants.SEARCH_USER))
		{
			LOG.info("LoginServlet.doPost -- Searching Users");
			if(session.getAttribute(HomeInsuranceConstants.LOCATION) != null)
			{	
				LOG.info("LoginServlet.doPost -- Session Attribute Location Found");
				session.removeAttribute(HomeInsuranceConstants.HOMEOWNER);
				if(session.getAttribute(HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO)!=null) {
					int quoteId = (int)session.getAttribute(HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO);
					try {
						ServletOperations.purgeIncomplete(quoteId, HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO);
					} catch (HomequoteSystemException e) {
						LOG.error("Exception occurred in method LoginServlet.doPost :: "
								+ e);
						request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
						final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
						dispatcher.forward(request, response);
					}
				}
				session.removeAttribute(HomeInsuranceConstants.LOCATION);
				if(session.getAttribute(HomeInsuranceConstants.INCOMPLETE_LOCATION)!=null) {
					int quoteId = (int)session.getAttribute(HomeInsuranceConstants.INCOMPLETE_LOCATION);
					try {
						ServletOperations.purgeIncomplete(quoteId, HomeInsuranceConstants.INCOMPLETE_LOCATION);
					} catch (HomequoteSystemException e) {
						LOG.error("Exception occurred in method LoginServlet.doPost :: "
								+ e);
						request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
						final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
						dispatcher.forward(request, response);
					}
				}
				session.removeAttribute(HomeInsuranceConstants.PROPERTY);
				session.removeAttribute(HomeInsuranceConstants.REQUEST_SOURCE);
				LOG.info("LoginServlet.doPost -- Removed Location, Homeowner, and Property Session Attributes");
			}
			else
				LOG.info("LoginServlet.doPost -- Session Attribute Location Not Found");
			
			session.invalidate();
			LOG.info("LoginServlet.doPost -- Invalidated Session");
		}
		session = request.getSession(true);
		LOG.info("LoginServlet.doPost -- New Session");
		if(action.equals(HomeInsuranceConstants.EXISTING_USER))
		{
			LOG.info("LoginServlet.doPost -- Existing User");
			loginExistingUser(request, response, LOG, session);
		}
		else if(action.equals(HomeInsuranceConstants.NEW_USER))
		{
			LOG.info("LoginServlet.doPost -- New User");
			loginNewUser(request, response, LOG, session);
		}
		else if(action.equals(HomeInsuranceConstants.SEARCH_USER))
		{
			LOG.info("LoginServlet.doPost -- Search User");
			searchUser(request, response, LOG, session);
		}
		else if(action.equals(HomeInsuranceConstants.LOGOUT))
		{
			LOG.info("LoginServlet.doPost -- Logout");
			session.invalidate();
			LOG.info("LoginServlet.doPost -- Session Invalidated");
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.LOGOUT_PAGE);
			LOG.info("LoginServlet.doPost -- Forwarding to: "+HomeInsuranceConstants.LOGOUT_PAGE);
			dispatcher.forward(request, response);
		}
		else
			LOG.info("LoginServlet.doPost -- No Action Found");
	}

	/**This method provides an user search tool for the administrators
	 * @param req is the request received. Contains attributes and parameters.
	 * @param res is the response returned
	 * @param logger is the log writer
	 * @param session is the session containing attributes.
	 * @throws ServletException
	 * @throws IOException
	 */
	private void searchUser(final HttpServletRequest req,
			final HttpServletResponse res, final Logger logger,
			final HttpSession session) throws ServletException, IOException {
		LOG.info("LoginServlet.searchUser -- Start");
		try {
			String page = null;
			final String selectedUser = req.getParameter(HomeInsuranceConstants.SELECTED_USER);
			LOG.info("LoginServlet.searchUser -- Selected User: "+selectedUser);
			final LoginBO loginBO = new LoginBO();
			final User user = loginBO.getUser(selectedUser);
			LOG.info("LoginServlet.searchUser -- Fetched User from Database: "+user);
			if(user != null)
			{
				session.setAttribute(HomeInsuranceConstants.USER_NAME, selectedUser);
				LOG.info("LoginServlet.searchUser -- Saved selectedUser to session");
				//Get Policy
				final PolicyBO policyBO = new PolicyBO();
				final List<Policy> policyList = policyBO.getPolicies(selectedUser);
				LOG.info("LoginServlet.searchUser -- Fetched policy list");
				if(policyList.isEmpty())
				{
					LOG.info("LoginServlet.searchUser -- Policy list is empty");
					page = HomeInsuranceConstants.GET_STARTED_PAGE;
				}
				else
				{
					LOG.info("LoginServlet.searchUser -- Policy Details Page");
					req.setAttribute("policyList", policyList);
					page = HomeInsuranceConstants.POLICY_DETAILS_PAGE;
				}
			}
			else
			{
				LOG.info("LoginServlet.searchUser -- Invalid Username");
				req.setAttribute(HomeInsuranceConstants.MESSAGE, "Invalid UserName");
				page = HomeInsuranceConstants.SEARCH_USER_PAGE;
			}
			LOG.info("LoginServlet.searchUser -- Forwarding to: "+page);
			LOG.info("LoginServlet.searchUser -- End");
			final RequestDispatcher dispatcher = req.getRequestDispatcher(page);
			dispatcher.forward(req, res);
		
		} catch (Exception e) {
			logger.error("Exception occurred while executing method LoginServlet.doGet :: " + e);
			req.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = req.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(req, res);
		}
	}

	/**This method logs in a new user just created
	 * @param req is the request. It contains attributes and parameters
	 * @param res is the response returned
	 * @param logger is the log writer
	 * @param session is the session containing attributes
	 * @throws ServletException
	 * @throws IOException
	 */
	private void loginNewUser(final HttpServletRequest req,
			final HttpServletResponse res, final Logger logger,
			final HttpSession session) throws ServletException, IOException {
		LOG.info("LoginServlet.loginNewUser -- Start");
		final String userName = req.getParameter(HomeInsuranceConstants.USER_NAME);
		LOG.info("LoginServlet.loginNewUser -- userName: "+userName);
		final String password = req.getParameter(HomeInsuranceConstants.PASSWORD);
		LOG.info("LoginServlet.loginNewUser -- password: "+password);
		final User user = new User();
		user.setUserName(userName);
		user.setPassword(password);
		LOG.info("LoginServlet.loginNewUser -- User object set: "+user.toString());
		try {
			final LoginBO loginBO = new LoginBO();
			loginBO.registerUser(user);
			session.setAttribute(HomeInsuranceConstants.USER_NAME, userName);
			LOG.info("LoginServlet.loginNewUser -- userName save to session");
			LOG.info("LoginServlet.loginNewUser -- Forwarding to: "+HomeInsuranceConstants.GET_STARTED_PAGE);
			LOG.info("LoginServlet.loginNewUser -- End");
			final RequestDispatcher dispatcher = req.getRequestDispatcher(HomeInsuranceConstants.GET_STARTED_PAGE);
			dispatcher.forward(req, res);
		} catch (Exception e) {
			logger.error("Exception occurred while executing method LoginServlet.doGet :: " + e);
			req.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = req.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(req, res);
		}
	}

	/**This method logs in an existing user. If the user is an Admin, then sets the session for an admin user.
	 * @param req is an HttpServletRequest object containing attributes and parameters.
	 * @param res is an HttpServletResponse object
	 * @param logger is a log writer
	 * @param session is a session containing attributes
	 * @throws ServletException
	 * @throws IOException
	 */
	@SuppressWarnings("unused")
	private void loginExistingUser(final HttpServletRequest req,
			final HttpServletResponse res, final Logger logger,
			final HttpSession session) throws ServletException, IOException {
		LOG.info("LoginServlet.loginExistingUser -- Start");
		try {
			final String userName = req.getParameter(HomeInsuranceConstants.USER_NAME);
			LOG.info("LoginServlet.loginExistingUser -- userName: "+userName);
			final String password = req.getParameter(HomeInsuranceConstants.PASSWORD);
			LOG.info("LoginServlet.loginExistingUser -- password: "+password);
			String page = null;
			final LoginBO loginBO = new LoginBO();
			final User user = loginBO.getUser(userName);
			LOG.info("LoginServlet.loginExistingUser -- User set: "+user.toString());
			if(user != null)
			{
				if(user.getUserRole() != null && user.getUserRole().equals(HomeInsuranceConstants.ADMIN))
				{
					LOG.info("LoginServlet.loginExistingUser -- User is Admin");
					session.setAttribute(HomeInsuranceConstants.ROLE, HomeInsuranceConstants.ADMIN);
					LOG.info("LoginServlet.loginExistingUser -- Set Admin Role in Session");
					page = HomeInsuranceConstants.SEARCH_USER_PAGE;
				}
				else
				{
					LOG.info("LoginServlet.loginExistingUser -- User not Admin");
					session.setAttribute(HomeInsuranceConstants.ROLE, HomeInsuranceConstants.USER);
					LOG.info("LoginServlet.loginExistingUser -- Saved role to session");
					session.setAttribute(HomeInsuranceConstants.USER_NAME, userName);
					LOG.info("LoginServlet.loginExistingUser -- Set userName in Session");
					if(!user.getPassword().equals(password))
					{
						LOG.info("LoginServlet.loginExistingUser -- Wrong password");
						throw new HomequoteBusinessException("Invalid Password");
					}
					
					//Get Policy
					final PolicyBO policyBO = new PolicyBO();
					final List<Policy> policyList = policyBO.getPolicies(userName);
					LOG.info("LoginServlet.loginExistingUser -- Fetched policy list");
					if(policyList.isEmpty())
					{
						LOG.info("LoginServlet.loginExistingUser -- Policy list is empty");
						page = HomeInsuranceConstants.GET_STARTED_PAGE;
					}
					else
					{
						LOG.info("LoginServlet.loginExistingUser -- Policy list found");
						req.setAttribute(HomeInsuranceConstants.POLICY_LIST, policyList);
						LOG.info("LoginServlet.loginExistingUser -- Stored policy list in request");
						page = HomeInsuranceConstants.POLICY_DETAILS_PAGE;
					}
				}
			}
			else
			{
				LOG.error("LoginServlet.loginExistingUser -- Error");
				req.setAttribute(HomeInsuranceConstants.MESSAGE, "Invalid UserName");
				page = HomeInsuranceConstants.ERROR;
			}
			LOG.info("LoginServlet.loginExistingUser -- Forwarding to: "+page);
			LOG.info("LoginServlet.loginExistingUser -- End");
			final RequestDispatcher dispatcher = req.getRequestDispatcher(page);
			dispatcher.forward(req, res);				
		} catch (Exception e) {
			logger.error("Exception occurred while executing method LoginServlet.doPost :: " + e);
			req.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = req.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(req, res);
		}
	}
}