/**HomeownerInfoServlet class is a servlet that manages the information received from the homeownerInfo.jsp page form
 * @author Benjamin Edelstein
 * @contact BenLEdelstein@gmail.com
 * @version 1.0
 */
package com.cts.insurance.homequote.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.insurance.homequote.bo.HomeownerBO;
import com.cts.insurance.homequote.exception.HomequoteSystemException;
import com.cts.insurance.homequote.model.Homeowner;
import com.cts.insurance.homequote.model.Location;
import com.cts.insurance.homequote.util.HomeInsuranceConstants;

public class HomeownerInfoServlet extends HttpServlet{
	
	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Logger
	 */
	private static final Logger LOG = Logger.getLogger(HomeownerInfoServlet.class);
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,IOException {
		LOG.info("HomeownerInfoServlet.doPost -- Start");
		String forward = null;
		try {
			final HttpSession session = request.getSession();
			final String userName = (String)session.getAttribute(HomeInsuranceConstants.USER_NAME);
			LOG.info("HomeownerInfoServlet.doPost -- User Name: "+userName);
			final String requestSource =  (String)session.getAttribute(HomeInsuranceConstants.REQUEST_SOURCE);
			if(userName!=null && requestSource!=null && requestSource.equals(HomeInsuranceConstants.LOCATION_PAGE)) {
				if(session.getAttribute(HomeInsuranceConstants.HOMEOWNER) == null)
				{
					LOG.info("HomeownerInfoServlet.doPost -- Session Attribute Homeowner Not Found");
					//Get Request Parameters and set it to the data object
					final Homeowner homeowner = new Homeowner();
					homeowner.setFirstName(request.getParameter(HomeInsuranceConstants.FIRST_NAME));
					LOG.info("Homeowner firstName set as "+homeowner.getFirstName());
					homeowner.setLastName(request.getParameter(HomeInsuranceConstants.LAST_NAME));
					LOG.info("Homeowner lastName set as "+homeowner.getLastName());
					homeowner.setDob(request.getParameter(HomeInsuranceConstants.DATE_OF_BIRTH));
					LOG.info("Homeowner dob set as "+homeowner.getDob());
					homeowner.setIsRetired(request.getParameter(HomeInsuranceConstants.IS_RETIRED));
					LOG.info("Homeowner isRetired set as "+homeowner.getIsRetired());
					homeowner.setSsn(request.getParameter(HomeInsuranceConstants.SSN));
					LOG.info("Homeowner ssn set as "+homeowner.getSsn().replace(".", "*"));
					homeowner.setEmailAddress(request.getParameter(HomeInsuranceConstants.EMAIL_ADDRESS));
					LOG.info("Homeowner emailAddress set as "+homeowner.getEmailAddress());
					
					if(session.getAttribute(HomeInsuranceConstants.LOCATION) != null)
					{
						LOG.info("HomeownerInfoServlet.doPost -- Session Attribute Location Found");
						final Location location = (Location)session.getAttribute(HomeInsuranceConstants.LOCATION);
						homeowner.setQuoteId(location.getQuoteId());
						LOG.info("Homeowner quoteId set as "+homeowner.getQuoteId());
					}
					else
					{
						String message = "QuoteId not retrieved after location page in method HomeownerInfoServlet.doPost";
						LOG.error(message);
						throw new HomequoteSystemException(message);
					}
					
					final HomeownerBO homeownerBo = new HomeownerBO();
					homeownerBo.saveHomeownerInfo(homeowner);
					LOG.info("Homeowner saved to database");
					session.setAttribute(HomeInsuranceConstants.INCOMPLETE_HOMEOWNERINFO, homeowner.getQuoteId());
					LOG.info("Incomplete form state save to session");
					session.setAttribute(HomeInsuranceConstants.HOMEOWNER, homeowner);
					LOG.info("Homeowner saved to session");
					
				}
				else {
					final Homeowner homeowner = (Homeowner)session.getAttribute(HomeInsuranceConstants.HOMEOWNER);
					LOG.info("Session already exists - Homeowner Object: "+homeowner.toSafeString());
				}
				LOG.info("HomeownerInfoServlet.doPost - Forwarding to: "+HomeInsuranceConstants.PROPERTY_PAGE);
				session.setAttribute(HomeInsuranceConstants.REQUEST_SOURCE, HomeInsuranceConstants.HOMEOWNER_INFO_PAGE);
				LOG.info("HomeownerInfoServlet.doPost -- Set forwarding page in request");
				forward = HomeInsuranceConstants.PROPERTY_PAGE;
			}
			else {
				LOG.info("HomeownerInfoServlet.doPost -- Request not from location or no user logged in");
				forward = HomeInsuranceConstants.WELCOME_PAGE;
				request.setAttribute(HomeInsuranceConstants.MESSAGE, "Session Interrupted: Session was closed, please log back in.");
			}
			LOG.info("HomeownerInfoServlet.doPost -- END");
			final RequestDispatcher dispatcher = request.getRequestDispatcher(forward);
			dispatcher.forward(request, response);
			
		} catch (Exception e) {
 			LOG.error("Exception occurred in method HomeownerInfoServlet.doPost :: "
					+ e);
			request.setAttribute(HomeInsuranceConstants.MESSAGE, e.getLocalizedMessage());
			final RequestDispatcher dispatcher = request.getRequestDispatcher(HomeInsuranceConstants.ERROR);
			dispatcher.forward(request, response);
		}
	}
}